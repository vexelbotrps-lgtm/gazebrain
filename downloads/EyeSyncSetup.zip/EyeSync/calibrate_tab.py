"""Calibrate personalized bilateral eye-closure thresholds for the Tab gesture.

Only numeric eye-aspect-ratio measurements are processed; no webcam images or
video are saved.
"""
from __future__ import annotations

import argparse
import json
import sys
import time

import cv2
import numpy as np

import gaze_core as gc

EXPRESSIONS = (
    ("open", "Keep both eyes comfortably open"),
    ("closed", "Close both eyes gently"),
)
READY_SECONDS = 4.0
SAMPLE_SECONDS = 5.0
SAMPLE_INTERVAL_S = 0.12
MIN_SAMPLES = 25
MIN_SEPARATION = 0.06
CLOSED_PERCENTILE = 90
OPEN_PERCENTILE = 10
CLOSE_THRESHOLD_FRACTION = 0.35
OPEN_THRESHOLD_FRACTION = 0.75


def run(camera: int = gc.CAMERA_INDEX) -> dict[str, dict[str, np.ndarray]]:
    cap = gc.open_camera(camera)
    extractor = gc.FaceFeatureExtractor()
    samples: dict[str, dict[str, list[float]]] = {
        expression: {"left": [], "right": []}
        for expression, _ in EXPRESSIONS
    }
    window = "Tab eye-closure calibration (ESC cancels)"
    try:
        for expression, instruction in EXPRESSIONS:
            started = time.monotonic()
            last_sample = float("-inf")
            while True:
                elapsed = time.monotonic() - started
                if elapsed >= READY_SECONDS + SAMPLE_SECONDS:
                    break
                ok, frame = cap.read()
                if not ok or frame is None:
                    raise gc.CameraError(
                        f"Camera stopped delivering frames during the {expression}-eyes step."
                    )
                result = extractor.process(frame)
                recording = elapsed >= READY_SECONDS
                if (recording and result is not None
                        and elapsed - last_sample >= SAMPLE_INTERVAL_S):
                    samples[expression]["left"].append(float(result.ear_left))
                    samples[expression]["right"].append(float(result.ear_right))
                    last_sample = elapsed

                remaining = (READY_SECONDS + SAMPLE_SECONDS - elapsed
                             if recording else READY_SECONDS - elapsed)
                prompt = instruction if recording else f"Get ready: {instruction}"
                cv2.rectangle(frame, (0, 0), (frame.shape[1], 72), (0, 0, 0), -1)
                cv2.putText(frame, f"{prompt} [{remaining:.0f}s]", (8, 27),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.52,
                            (0, 255, 0) if recording else (0, 200, 255), 2)
                message = (
                    "Face not detected" if result is None else
                    f"EAR L/R {result.ear_left:.3f}/{result.ear_right:.3f}  "
                    f"samples {len(samples[expression]['left'])}"
                )
                cv2.putText(frame, message, (8, 58), cv2.FONT_HERSHEY_SIMPLEX,
                            0.58, (0, 255, 255), 2)
                cv2.imshow(window, frame)
                if cv2.waitKey(1) & 0xFF == 27:
                    raise KeyboardInterrupt("Tab gesture calibration cancelled.")
    finally:
        cap.release()
        extractor.close()
        cv2.destroyAllWindows()

    for expression, _ in EXPRESSIONS:
        values = samples[expression]
        if min(len(values["left"]), len(values["right"])) < MIN_SAMPLES:
            raise ValueError(
                f"Only {len(values['left'])} valid eye samples were recorded while "
                f"eyes were {expression}; at least {MIN_SAMPLES} are required. "
                "Keep your face centered and improve lighting before retrying."
            )
    return {
        expression: {
            eye: np.asarray(values[eye], dtype=np.float64)
            for eye in ("left", "right")
        }
        for expression, values in samples.items()
    }


def build_profile(samples: dict[str, dict[str, np.ndarray]]) -> dict[str, float | int]:
    profile: dict[str, float | int] = {"version": gc.TAB_PROFILE_VERSION}
    for eye in ("left", "right"):
        try:
            open_values = np.asarray(samples["open"][eye], dtype=np.float64)
            closed_values = np.asarray(samples["closed"][eye], dtype=np.float64)
        except (KeyError, TypeError) as exc:
            raise ValueError(f"Open and closed {eye}-eye samples are required.") from exc
        if (open_values.ndim != 1 or closed_values.ndim != 1
                or len(open_values) < MIN_SAMPLES
                or len(closed_values) < MIN_SAMPLES
                or not np.all(np.isfinite(open_values))
                or not np.all(np.isfinite(closed_values))):
            raise ValueError(
                f"At least {MIN_SAMPLES} finite open and closed samples are "
                f"required for the {eye} eye."
            )

        baseline = float(np.median(open_values))
        if baseline <= 1e-5:
            raise ValueError(f"Could not establish an open-eye baseline for the {eye} eye.")
        open_floor = float(np.percentile(open_values, OPEN_PERCENTILE)) / baseline
        closed_ceiling = (
            float(np.percentile(closed_values, CLOSED_PERCENTILE)) / baseline
        )
        separation = open_floor - closed_ceiling
        if not np.isfinite(separation) or separation < MIN_SEPARATION:
            raise ValueError(
                f"Open and closed measurements for the {eye} eye overlap too much. "
                "Repeat calibration with both eyes fully open, then fully closed."
            )
        profile[f"close_ratio_{eye}"] = (
            closed_ceiling + CLOSE_THRESHOLD_FRACTION * separation
        )
        profile[f"open_ratio_{eye}"] = (
            closed_ceiling + OPEN_THRESHOLD_FRACTION * separation
        )
    return profile


def save_profile(profile: dict[str, float | int]) -> None:
    if gc.load_tab_profile_from_data(profile) is None:
        raise ValueError("The generated Tab calibration profile is invalid.")
    temporary = gc.TAB_PROFILE_PATH.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(profile, indent=2), encoding="utf-8")
    temporary.replace(gc.TAB_PROFILE_PATH)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Calibrate both-eyes-closed Tab gesture thresholds."
    )
    parser.add_argument("--camera", type=int, default=gc.CAMERA_INDEX)
    args = parser.parse_args()
    try:
        profile = build_profile(run(args.camera))
        save_profile(profile)
    except (gc.CameraError, ValueError, KeyboardInterrupt) as exc:
        print(f"Tab gesture calibration failed: {exc}", file=sys.stderr)
        return 1
    print(f"Saved personalized both-eyes-closed Tab calibration to {gc.TAB_PROFILE_PATH}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
