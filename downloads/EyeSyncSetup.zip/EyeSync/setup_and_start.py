"""Start EyeSync directly, with an explicit optional calibration mode."""
from __future__ import annotations

import asyncio
import argparse
import json
import socket
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlparse

from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed, InvalidStatus

import gaze_core as gc
import calibrate_left_click as smile_data
import calibrate_right_click as wink_data

ROOT = Path(__file__).resolve().parent
TRACKER_URI = "ws://localhost:8765"
TRACKER_HANDSHAKE_ATTEMPTS = 5
TRACKER_HANDSHAKE_RETRY_S = 1.0


def choose_tracker_port() -> int:
    """Keep the usual port when free; otherwise ask Windows for an unused one."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        try:
            probe.bind(("127.0.0.1", 8765))
            return 8765
        except OSError:
            probe.bind(("127.0.0.1", 0))
            return int(probe.getsockname()[1])


def start_wispr_command_panel(port: int) -> subprocess.Popen:
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    interpreter = str(pythonw if pythonw.is_file() else Path(sys.executable))
    command = [
        interpreter,
        str(ROOT / "wispr_command_panel.py"),
        "--ws-host", "127.0.0.1",
        "--ws-port", str(port),
    ]
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return subprocess.Popen(command, cwd=ROOT, creationflags=creationflags)


def stop_wispr_command_panel(process: subprocess.Popen) -> None:
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()


def start_tracker() -> int:
    tracker_port = choose_tracker_port()
    if tracker_port != 8765:
        print(
            f"Port 8765 is already in use. EyeSync will use "
            f"ws://127.0.0.1:{tracker_port} to avoid the port conflict.",
            flush=True,
        )
    try:
        command_panel = start_wispr_command_panel(tracker_port)
    except OSError as exc:
        print(f"Could not start the Wispr command panel: {exc}", flush=True)
        return 1
    try:
        return subprocess.run(
            [sys.executable, str(ROOT / "live.py"),
             "--standalone-mouse", "--enable-click-gestures",
             "--ws-host", "127.0.0.1",
             "--ws-port", str(tracker_port)],
            cwd=ROOT,
            check=False,
        ).returncode
    finally:
        stop_wispr_command_panel(command_panel)


def missing_calibrations() -> list[str]:
    missing = []
    try:
        gc.load_model_bundle()
    except (FileNotFoundError, ValueError):
        missing.append("gaze")
    return missing


def missing_sample_collections() -> list[str]:
    missing = []
    if not smile_data.has_saved_samples():
        missing.append("smile samples")
    if not wink_data.has_saved_samples():
        missing.append("wink samples")
    return missing


def missing_tab_calibration() -> bool:
    return gc.load_tab_profile() is None


def run_step(name: str, script: str, *arguments: str) -> bool:
    command = [sys.executable, str(ROOT / script), *arguments]
    print(
        f"\nStarting required {name} setup. Follow the on-screen prompts. "
        "Any error details will appear below.",
        flush=True,
    )
    result = subprocess.run(
        command,
        cwd=ROOT,
        check=False,
    )
    if result.returncode != 0:
        print(
            f"\nRequired {name} setup did not complete (exit code "
            f"{result.returncode}). The tracker will not start.",
            flush=True,
        )
        print(
            f"To see the error directly, close this window, open Command "
            f"Prompt in {ROOT}, and run: python {script} {' '.join(arguments)}",
            flush=True,
        )
        return False
    return True


async def use_running_tracker(calibrate: bool) -> bool:
    """Reuse an auto-started tracker so calibration never competes for its camera."""
    ws = None
    for attempt in range(TRACKER_HANDSHAKE_ATTEMPTS):
        try:
            ws = await connect(TRACKER_URI, open_timeout=2, close_timeout=2)
            break
        except ConnectionRefusedError:
            return False
        except InvalidStatus as exc:
            status = exc.response.status_code
            if status == 503 and attempt + 1 < TRACKER_HANDSHAKE_ATTEMPTS:
                await asyncio.sleep(TRACKER_HANDSHAKE_RETRY_S)
                continue
            print(
                f"The service on {TRACKER_URI} is not accepting EyeSync "
                f"WebSocket connections (HTTP {status}); starting this tracker "
                "on a separate local port instead.",
                flush=True,
            )
            return False
        except TimeoutError as exc:
            endpoint = urlparse(TRACKER_URI)
            try:
                with socket.create_connection(
                        (endpoint.hostname, endpoint.port), timeout=1):
                    pass
            except (ConnectionRefusedError, TimeoutError):
                return False
            except OSError as probe_error:
                raise RuntimeError(
                    f"Could not check the local tracker endpoint: {probe_error}"
                ) from probe_error
            print(
                f"The service on {TRACKER_URI} did not complete an EyeSync "
                "WebSocket handshake; starting this tracker on a separate "
                "local port instead.",
                flush=True,
            )
            return False
        except OSError as exc:
            raise RuntimeError(f"Could not connect to the local tracker: {exc}") from exc

    if ws is None:
        raise RuntimeError(f"Could not connect to the local tracker at {TRACKER_URI}.")

    async with ws:
        initial = json.loads(await asyncio.wait_for(ws.recv(), timeout=5))
        if initial.get("status") != "calibration_state":
            raise RuntimeError(
                f"Unexpected response from {TRACKER_URI}; refusing to start "
                "another process that might compete for the webcam."
            )

        if calibrate:
            print("\nUsing the running EyeSync tracker for required setup so it can "
                  "release and hand over the webcam safely.")
            await ws.send(json.dumps({
                "cmd": "calibration_consent",
                "accepted": True,
            }))
            while True:
                message = json.loads(await asyncio.wait_for(ws.recv(), timeout=1200))
                status = message.get("status")
                if status in {"calibrating", "calibration_done", "calibration_failed"}:
                    print(message.get("message", status), flush=True)
                if status == "calibration_failed":
                    raise RuntimeError(message.get("message", "Calibration failed."))
                if status == "calibration_done":
                    missing = missing_calibrations()
                    missing_samples = missing_sample_collections()
                    missing_tab = missing_tab_calibration()
                    required_missing = [name for name in missing if name == "gaze"]
                    if required_missing:
                        raise RuntimeError(
                            "The running tracker reported calibration complete, "
                            "but required profiles are still missing: "
                            + ", ".join(required_missing)
                        )
                    if missing_samples:
                        raise RuntimeError(
                            "Sample collection is required before use; these "
                            "numeric sample archives are missing or invalid: "
                            + ", ".join(missing_samples)
                        )
                    if missing_tab:
                        raise RuntimeError(
                            "The both-eyes-closed Tab calibration is missing or invalid."
                        )
                    break

        command_panel = start_wispr_command_panel(8765)
        try:
            print("Waiting for the running tracker to resume the camera and preview...")
            while True:
                message = json.loads(await asyncio.wait_for(ws.recv(), timeout=90))
                if isinstance(message.get("x"), (int, float)) and isinstance(
                        message.get("y"), (int, float)):
                    break
                if message.get("status") in {"camera_error", "needs_calibration",
                                             "calibration_failed"}:
                    raise RuntimeError(message.get("message", "Tracker is not ready."))

            await ws.send(json.dumps({"cmd": "mouse", "enabled": True}))
            print("Preview is ready; mouse control requested.")
            try:
                while True:
                    message = json.loads(await ws.recv())
                    if message.get("status") == "mouse":
                        print(message.get("message", "Mouse control state updated."),
                              flush=True)
                    elif message.get("click") in {"left", "right"}:
                        print(f"{message['click'].capitalize()} click detected.",
                              flush=True)
                    elif message.get("keyboard_opened"):
                        print("On-screen keyboard opened.", flush=True)
            except KeyboardInterrupt:
                print("\nDisconnected from the tracker; mouse control turns off "
                      "when this launcher closes.")
            except ConnectionClosed:
                print("\nThe tracker disconnected. Restart it before continuing.")
        finally:
            stop_wispr_command_panel(command_panel)
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Start EyeSync with optional calibration.")
    parser.add_argument(
        "--calibrate",
        action="store_true",
        help="run missing gaze, gesture-sample, and Tab-gesture calibration before starting",
    )
    args = parser.parse_args()
    if not args.calibrate:
        print(
            "Calibration is optional. Starting EyeSync without running calibration; "
            "cursor control remains off until gaze calibration is valid.",
            flush=True,
        )
        return start_tracker()

    missing = missing_calibrations()
    missing_samples = missing_sample_collections()
    missing_tab = missing_tab_calibration()
    required_missing = [name for name in missing if name == "gaze"]
    if missing or missing_samples or missing_tab:
        print("Running the requested calibration and sample collection steps.")
        if required_missing:
            print("Missing or invalid required calibration: "
                  + ", ".join(required_missing))
        if missing_samples:
            print("Missing or incomplete sample collections: " + ", ".join(missing_samples))
        if missing_tab:
            print("Missing or invalid both-eyes-closed Tab calibration.")

    try:
        if asyncio.run(use_running_tracker(
                calibrate=bool(required_missing or missing_samples or missing_tab))):
            return 0
    except KeyboardInterrupt:
        print("\nStopped.")
        return 0
    except (RuntimeError, asyncio.TimeoutError, OSError, ValueError) as exc:
        print(f"\nCould not safely use the running tracker: {exc}")
        print("Mouse control remains off. Resolve the tracker/port issue and retry.")
        return 1

    if missing or missing_samples or missing_tab:
        steps = {"gaze": ("calibrate.py", "--auto-start")}
        selected = [name for name in steps if name in missing]
        for name in selected:
            script, *arguments = steps[name]
            if not run_step(name, script, *arguments):
                return 1
        missing_samples = missing_sample_collections()
        sample_steps = {
            "smile samples": ("calibrate_left_click.py", "--samples-only"),
            "wink samples": ("calibrate_right_click.py", "--samples-only"),
        }
        for name, (script, *arguments) in sample_steps.items():
            if name not in missing_samples:
                continue
            if not run_step(name, script, *arguments):
                return 1
        missing_samples = missing_sample_collections()
        if missing_samples:
            print("Required sample collection is incomplete: " + ", ".join(missing_samples))
            print("The tracker will not start until all required samples are saved.")
            return 1
        if missing_tab and not run_step("Tab gesture", "calibrate_tab.py"):
            return 1
        missing = missing_calibrations()
        required = [name for name in missing if name == "gaze"]
        if required:
            print("Required gaze calibration is incomplete.")
            return 1
        if missing_tab_calibration():
            print("Both-eyes-closed Tab calibration is incomplete.")
            return 1
        optional_missing = [name for name in missing if name != "gaze"]
        if optional_missing:
            print(
                "Starting with collected samples. Optional personalized gesture "
                "profiles are unavailable: " + ", ".join(optional_missing)
                + ". Built-in behavior is used where supported."
            )

    print("\nGaze calibration is valid. Starting the tracker.")
    return start_tracker()


if __name__ == "__main__":
    raise SystemExit(main())
