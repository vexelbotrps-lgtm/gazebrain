"""Install EyeSync's local dependencies once, then open its two-button app.

This script is run by EyeSync.bat from the downloaded project ZIP.
"""
from __future__ import annotations

import hashlib
import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV_DIR = ROOT / ".venv"
REQUIREMENTS = ROOT / "requirements.txt"
APP_SCRIPT = ROOT / "eyesync_app.py"
INSTALL_MARKER = VENV_DIR / ".requirements-installed"


def find_python() -> list[str]:
    candidates: list[tuple[tuple[int, int], list[str]]] = []
    if shutil.which("py"):
        versions = subprocess.run(
            ["py", "-0"],
            capture_output=True,
            text=True,
            check=False,
        )
        if versions.returncode == 0:
            for line in versions.stdout.splitlines():
                match = re.search(r"(?:-V:|-)(\d+)\.(\d+)(?:t)?(?:[-\s]|$)", line)
                if match:
                    major, minor = map(int, match.groups())
                    if major == 3 and 10 <= minor <= 12:
                        candidates.append(((major, minor), ["py", f"-{major}.{minor}"]))
        if not candidates:
            candidates.append(((3, 0), ["py", "-3"]))

    for executable in ("python", "python3"):
        if shutil.which(executable):
            candidates.append(((0, 0), [executable]))

    available: list[tuple[tuple[int, int], list[str]]] = []
    seen: set[tuple[str, ...]] = set()
    for _, candidate in candidates:
        signature = tuple(candidate)
        if signature in seen:
            continue
        seen.add(signature)
        try:
            result = subprocess.run(
                [*candidate, "--version"],
                capture_output=True,
                text=True,
                check=False,
            )
            match = re.search(r"Python (\d+)\.(\d+)", result.stdout + result.stderr)
            if result.returncode == 0 and match:
                major, minor = map(int, match.groups())
                if major == 3 and 10 <= minor <= 12:
                    available.append(((major, minor), candidate))
        except OSError:
            continue

    if available:
        available.sort(key=lambda item: item[0], reverse=True)
        return available[0][1]

    raise RuntimeError(
        "EyeSync supports Python 3.10 through 3.12. For Windows, install Python "
        "3.12.10 (64-bit) from https://www.python.org/ftp/python/3.12.10/"
        "python-3.12.10-amd64.exe and run EyeSync.bat again."
    )


def ensure_venv(python_cmd: list[str]) -> Path:
    python_path = VENV_DIR / "Scripts" / "python.exe"
    selected_version = _python_version(python_cmd)
    try:
        current_version = (
            _python_version([str(python_path)]) if python_path.exists() else None
        )
    except RuntimeError:
        current_version = None
    if current_version != selected_version:
        action = "Updating" if current_version else "Creating"
        print(
            f"{action} the local EyeSync environment with "
            f"Python {'.'.join(map(str, selected_version))}..."
        )
        command = [*python_cmd, "-m", "venv"]
        if current_version is not None:
            command.append("--clear")
        subprocess.run([*command, str(VENV_DIR)], check=True)
    return python_path


def _python_version(command: list[str]) -> tuple[int, int, int]:
    result = subprocess.run(
        [*command, "--version"],
        capture_output=True,
        text=True,
        check=False,
    )
    match = re.search(r"Python (\d+)\.(\d+)(?:\.(\d+))?", result.stdout + result.stderr)
    if result.returncode != 0 or not match:
        raise RuntimeError(f"Could not determine Python version for {command[0]}.")
    major, minor = map(int, match.groups()[:2])
    patch = int(match.group(3) or 0)
    if major != 3 or not 10 <= minor <= 12:
        raise RuntimeError("EyeSync requires Python 3.10, 3.11, or 3.12.")
    return major, minor, patch


def install_requirements(python_path: Path) -> None:
    if not REQUIREMENTS.exists():
        raise FileNotFoundError(f"Missing {REQUIREMENTS.name}. Re-download the project ZIP.")

    digest = hashlib.sha256(REQUIREMENTS.read_bytes()).hexdigest()
    if INSTALL_MARKER.exists() and INSTALL_MARKER.read_text(encoding="ascii") == digest:
        return
    print("Installing EyeSync dependencies. This may take a few minutes...")
    subprocess.run(
        [str(python_path), "-m", "pip", "install", "--upgrade", "pip"],
        check=True,
    )
    subprocess.run(
        [str(python_path), "-m", "pip", "install", "-r", str(REQUIREMENTS)],
        check=True,
    )
    INSTALL_MARKER.write_text(digest, encoding="ascii")


def prepare_environment() -> Path:
    python_cmd = find_python()
    venv_python = ensure_venv(python_cmd)
    install_requirements(venv_python)
    return venv_python


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--prepare-only",
        action="store_true",
        help="create the virtual environment and install requirements without launching the app",
    )
    args = parser.parse_args(argv)
    try:
        venv_python = prepare_environment()
        if args.prepare_only:
            print("EyeSync environment is ready.")
            return 0
        pythonw = venv_python.with_name("pythonw.exe")
        interpreter = pythonw if pythonw.is_file() else venv_python
        subprocess.Popen(
            [str(interpreter), str(APP_SCRIPT)],
            cwd=ROOT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return 0
    except RuntimeError as exc:
        print(f"\nSetup blocked: {exc}", flush=True)
        return 1
    except subprocess.CalledProcessError as exc:
        print(f"\nCommand failed with exit code {exc.returncode}.", flush=True)
        return exc.returncode
    except (OSError, ValueError) as exc:
        print(f"\nUnexpected setup error: {exc}", flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
