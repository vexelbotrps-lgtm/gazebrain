"""Collect smile samples and train the legacy mouth-image smile classifier.

The script records HOG mouth features in memory, never images or video.
Live left-click uses face-landmark mouth width; this classifier is not used by live.py.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import cv2
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC

import gaze_core as gc

PHASES = tuple(
    (f"{expression}_{pose}", instruction, pose, expression)
    for pose, direction in (
        ("center", "face the camera"),
        ("down", "tilt your head down"),
        ("left", "turn slightly left"),
        ("right", "turn slightly right"),
    )
    for expression, instruction in (
        ("neutral", f"Relax your face; {direction}"),
        ("closed_smile", f"Make a gentle closed-lip smile without teeth; {direction}"),
        ("teeth_relaxed", f"Show your teeth but keep your mouth relaxed; {direction}"),
        ("teeth_smile", f"Smile naturally while showing your teeth; {direction}"),
    )
)
POSES = ("center", "down", "left", "right")
READY_SECONDS = 5.0
SAMPLE_SECONDS = 7.0
MIN_SAMPLES = 35
MIN_VALIDATION_ACCURACY = 0.80
MIN_SCORE_SEPARATION = 0.10
SAMPLE_INTERVAL_S = 0.12
VALIDATION_FRACTION = 0.25
SAMPLES_PATH = Path(__file__).with_name("smile_samples.npz")
SAMPLE_ARCHIVE_VERSION = 1


def run(camera: int) -> dict[str, dict[str, np.ndarray]]:
    cap = gc.open_camera(camera)
    extractor = gc.FaceFeatureExtractor()
    samples: dict[str, dict[str, list]] = {
        key: {"hog": [], "pose": [], "yaw": []} for key, _, _, _ in PHASES
    }
    window = "legacy closed-lip smile profile calibration (ESC cancels)"
    try:
        for key, instruction, _pose_name, _label in PHASES:
            started = time.monotonic()
            last_sample = float("-inf")
            while True:
                elapsed = time.monotonic() - started
                if elapsed >= READY_SECONDS + SAMPLE_SECONDS:
                    break
                ok, frame = cap.read()
                if not ok or frame is None:
                    raise gc.CameraError(
                        f"Camera stopped delivering frames during '{key}'."
                    )
                result = extractor.process(frame)
                recording = elapsed >= READY_SECONDS
                if (recording and result is not None and result.mouth_patch is not None
                        and elapsed - last_sample >= SAMPLE_INTERVAL_S):
                    samples[key]["hog"].append(gc.mouth_patch_hog(result.mouth_patch))
                    samples[key]["pose"].append(float(result.smile_features[2]))
                    samples[key]["yaw"].append(float(result.smile_features[4]))
                    last_sample = elapsed

                remaining = (READY_SECONDS + SAMPLE_SECONDS - elapsed if recording
                             else READY_SECONDS - elapsed)
                prompt = instruction if recording else f"Get ready: {instruction}"
                cv2.rectangle(frame, (0, 0), (frame.shape[1], 72), (0, 0, 0), -1)
                cv2.putText(frame, f"{prompt} [{remaining:.0f}s]", (8, 26),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                            (0, 255, 0) if recording else (0, 200, 255), 2)
                if result is None:
                    message = "Face not detected"
                else:
                    message = (f"{'Recording' if recording else 'Ready'}  "
                               f"samples {len(samples[key]['hog'])}")
                cv2.putText(frame, message, (8, 58), cv2.FONT_HERSHEY_SIMPLEX,
                            0.65, (0, 255, 255), 2)
                cv2.imshow(window, frame)
                if cv2.waitKey(1) & 0xFF == 27:
                    raise KeyboardInterrupt("Calibration cancelled.")
    finally:
        cap.release()
        extractor.close()
        cv2.destroyAllWindows()

    for key, values in samples.items():
        if len(values["hog"]) < MIN_SAMPLES:
            raise ValueError(
                f"Only {len(values['hog'])} mouth samples recorded during '{key}'; "
                f"at least {MIN_SAMPLES} are required. Hold still with your mouth "
                "visible and improve lighting before retrying."
            )
    return {
        key: {name: np.asarray(values, dtype=np.float32)
              for name, values in measurements.items()}
        for key, measurements in samples.items()
    }


def save_samples(samples: dict[str, dict[str, np.ndarray]]) -> None:
    archived: dict[str, np.ndarray] = {
        "version": np.asarray(SAMPLE_ARCHIVE_VERSION, dtype=np.int32)
    }
    if has_saved_samples():
        with np.load(SAMPLES_PATH, allow_pickle=False) as previous:
            archived.update({key: previous[key] for key in previous.files
                             if key != "version"})
    for phase, measurements in samples.items():
        for name, values in measurements.items():
            key = f"{phase}__{name}"
            archived[key] = (np.concatenate((archived[key], values), axis=0)
                             if key in archived else values)
    temporary = SAMPLES_PATH.with_suffix(".npz.tmp")
    with temporary.open("wb") as stream:
        np.savez_compressed(stream, **archived)
    temporary.replace(SAMPLES_PATH)


def has_saved_samples() -> bool:
    try:
        with np.load(SAMPLES_PATH, allow_pickle=False) as archive:
            if int(archive["version"]) != SAMPLE_ARCHIVE_VERSION:
                return False
            for phase, *_ in PHASES:
                hog = archive[f"{phase}__hog"]
                pose = archive[f"{phase}__pose"]
                yaw = archive[f"{phase}__yaw"]
                if (hog.ndim != 2 or hog.shape[1] != gc._MOUTH_HOG.getDescriptorSize()
                        or len(hog) < MIN_SAMPLES or len(pose) != len(hog)
                        or len(yaw) != len(hog)
                        or not np.all(np.isfinite(hog))
                        or not np.all(np.isfinite(pose))
                        or not np.all(np.isfinite(yaw))):
                    return False
    except (OSError, ValueError, KeyError, TypeError):
        return False
    return True


def build_profile(samples: dict[str, dict[str, np.ndarray]]) -> dict:
    models = {}
    for key, _instruction, _pose_name, _expression in PHASES:
        if (key not in samples
                or any(name not in samples[key] or len(samples[key][name]) < MIN_SAMPLES
                       for name in ("hog", "pose", "yaw"))):
            raise ValueError(
                f"At least {MIN_SAMPLES} samples are required for '{key}'."
            )

    for pose_name in POSES:
        negative_keys = (
            f"neutral_{pose_name}",
            f"teeth_relaxed_{pose_name}",
            f"teeth_smile_{pose_name}",
        )
        positive_key = f"closed_smile_{pose_name}"
        negative_parts = tuple(samples[key]["hog"] for key in negative_keys)
        positive = samples[positive_key]["hog"]
        if any(values.ndim != 2
               or values.shape[1] != gc._MOUTH_HOG.getDescriptorSize()
               or not np.all(np.isfinite(values))
               for values in (*negative_parts, positive)):
            raise ValueError(f"Mouth samples for the {pose_name} pose are invalid.")
        negative_splits = [
            int(len(values) * (1.0 - VALIDATION_FRACTION))
            for values in negative_parts
        ]
        positive_count = len(positive)
        positive_split = int(positive_count * (1.0 - VALIDATION_FRACTION))
        if min(*(negative_splits),
               *(len(values) - split for values, split
                 in zip(negative_parts, negative_splits)),
               positive_split, len(positive) - positive_split) < 5:
            raise ValueError(
                f"Not enough sequential samples to validate the {pose_name} pose."
            )
        negative_train = [values[:split]
                          for values, split in zip(negative_parts, negative_splits)]
        negative_valid = [values[split:]
                          for values, split in zip(negative_parts, negative_splits)]
        X_train = np.vstack([*negative_train, positive[:positive_split]])
        y_train = np.concatenate([
            np.zeros(sum(map(len, negative_train)), dtype=np.int8),
            np.ones(positive_split, dtype=np.int8),
        ])
        X_valid = np.vstack([*negative_valid, positive[positive_split:]])
        y_valid = np.concatenate([
            np.zeros(sum(map(len, negative_valid)), dtype=np.int8),
            np.ones(positive_count - positive_split, dtype=np.int8),
        ])
        classifier = make_pipeline(
            StandardScaler(),
            LinearSVC(C=0.5, class_weight="balanced", random_state=42, max_iter=50000),
        )
        classifier.fit(X_train, y_train)
        validation_scores = classifier.decision_function(X_valid)
        accuracy = float(np.mean((validation_scores >= 0) == y_valid))
        non_smile_scores = validation_scores[y_valid == 0]
        smile_scores = validation_scores[y_valid == 1]
        nonsmile_ceiling = float(np.percentile(non_smile_scores, 95))
        smile_floor = float(np.percentile(smile_scores, 10))
        separation = smile_floor - nonsmile_ceiling
        if (accuracy < MIN_VALIDATION_ACCURACY
                or not np.isfinite(separation)
                or separation < MIN_SCORE_SEPARATION):
            raise ValueError(
                f"Your closed-lip smile and other mouth shapes still overlap in "
                f"the {pose_name} pose (validation accuracy={accuracy:.1%}, "
                f"other-expression P95={nonsmile_ceiling:.3f}, "
                f"closed-lip-smile P10={smile_floor:.3f}). The old calibration was kept. "
                "Retry with better lighting, keep your face fully visible, relax "
                "for neutral samples, smile gently without showing teeth, then "
                "show teeth with a relaxed mouth and with a natural smile."
            )
        models[pose_name] = {
            "classifier": classifier,
            "threshold": nonsmile_ceiling + 0.60 * separation,
            "release_threshold": nonsmile_ceiling + 0.25 * separation,
            "pose": float(np.median(np.concatenate([
                samples[key]["pose"] for key in (*negative_keys, positive_key)
            ]))),
            "yaw": float(np.median(np.concatenate([
                samples[key]["yaw"] for key in (*negative_keys, positive_key)
            ]))),
            "validation_accuracy": accuracy,
        }
    return {"version": gc.CLICK_PROFILE_VERSION, "models": models}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Collect smile samples or train the legacy smile classifier"
    )
    parser.add_argument("--camera", type=int, default=gc.CAMERA_INDEX)
    parser.add_argument("--samples-only", action="store_true",
                        help="collect and save numeric gesture samples without training a model")
    args = parser.parse_args()
    try:
        samples = run(args.camera)
        save_samples(samples)
        print(f"Saved and retained numeric smile samples at {SAMPLES_PATH}")
        if args.samples_only:
            return
        profile = build_profile(samples)
    except (gc.CameraError, ValueError, KeyboardInterrupt) as exc:
        sys.exit(str(exc))

    gc.joblib.dump(profile, gc.CLICK_PROFILE_PATH)
    print("Saved personalized closed-lip smile classifier to", gc.CLICK_PROFILE_PATH)
    for pose, model in profile["models"].items():
        print(f"{pose.capitalize()} pose validation accuracy: "
              f"{model['validation_accuracy']:.1%}")
    print("This legacy smile profile is not used for live left-click.")


if __name__ == "__main__":
    main()
