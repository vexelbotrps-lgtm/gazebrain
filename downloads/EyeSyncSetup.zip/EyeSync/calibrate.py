"""
calibrate.py - 9-point calibration + MLP training.

Run once:  python calibrate.py
For each of 9 screen points the user looks at the dot while we record 50 frames
of the 4-float face-bbox feature vector. An MLPRegressor then learns
features -> (x_px, y_px) and is saved with joblib (gaze_model.joblib).
Press ESC at any time to abort.
"""
from __future__ import annotations

import argparse
import ctypes
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pygame
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler

import gaze_core as gc

SAMPLES_PER_POINT = 100     # frames recorded per calibration point
SETTLE_SECONDS = 1.2        # time for the head to arrive before recording starts
EDGE_MARGIN = 0.06          # corner/edge points sit 6 percent inside the screen border
HOLDOUT_PER_POINT = 10      # last N frames of each point kept for a sanity check


class CalibrationAborted(Exception):
    pass


def make_dpi_aware() -> None:
    """Without this, Windows display scaling makes pygame report a smaller screen
    than the real pixel resolution (and cursor control needs real pixels)."""
    if sys.platform.startswith("win"):
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


GRID_N = 3   # set by --grid (3 -> 9 points, 4 -> 16 points)


def build_points(sw: int, sh: int) -> list[tuple[int, int]]:
    """GRID_N x GRID_N grid including corners and edges (row-major)."""
    fr = np.linspace(EDGE_MARGIN, 1 - EDGE_MARGIN, GRID_N)
    xs = [f * sw for f in fr]
    ys = [f * sh for f in fr]
    return [(int(x), int(y)) for y in ys for x in xs]


def check_quit() -> None:
    for event in pygame.event.get():
        if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN
                                         and event.key == pygame.K_ESCAPE):
            raise CalibrationAborted()


def blit_center(screen, font, text, color, y) -> None:
    surf = font.render(text, True, color)
    screen.blit(surf, surf.get_rect(center=(screen.get_width() // 2, y)))


def wait_for_space(screen, big, small) -> None:
    clock = pygame.time.Clock()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN
                                             and event.key == pygame.K_ESCAPE):
                raise CalibrationAborted()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                return
        h = screen.get_height()
        screen.fill((0, 0, 0))
        blit_center(screen, big, "Gaze calibration", (255, 255, 255), h // 2 - 70)
        blit_center(screen, small, "Sit comfortably. Keep your posture, but TURN and LEAN your whole head.",
                    (200, 200, 200), h // 2)
        blit_center(screen, small, "For each dot, clearly exaggerate: point your nose AT the dot.",
                    (200, 200, 200), h // 2 + 40)
        blit_center(screen, small, "Press SPACE to begin  -  ESC to abort",
                    (255, 200, 0), h // 2 + 110)
        pygame.display.flip()
        clock.tick(30)


def collect_point(screen, small, cap, extractor, ear_threshold, point, idx, total) -> list:
    """Show one dot; after a settle period record SAMPLES_PER_POINT valid frames."""
    sw, sh = screen.get_size()
    px, py = point
    samples: list = []
    t0 = time.monotonic()

    while len(samples) < SAMPLES_PER_POINT:
        check_quit()
        ok, frame = cap.read()
        if not ok or frame is None:
            raise gc.CameraError("Camera stopped delivering frames during calibration.")

        res = extractor.process(frame)       # always run it so tracking stays warm
        elapsed = time.monotonic() - t0
        settling = elapsed < SETTLE_SECONDS

        status = ""
        if res is None:
            status = "Face not detected - look at the camera area"
        elif res.ear < ear_threshold:
            status = "Eyes closed - please keep them open"   # skip: not looking at the dot
        elif not settling:
            samples.append(res.features)

        # ---- draw ----
        screen.fill((0, 0, 0))
        if settling:   # shrinking ring draws the eye to the dot
            ring = 22 + int(40 * (1 - elapsed / SETTLE_SECONDS))
            pygame.draw.circle(screen, (255, 200, 0), (px, py), ring, 3)
        pygame.draw.circle(screen, (255, 255, 255), (px, py), 22)
        pygame.draw.circle(screen, (220, 30, 30), (px, py), 7)

        blit_center(screen, small, f"Point {idx + 1}/{total}  -  look at the dot (ESC aborts)",
                    (200, 200, 200), 40)
        if status:
            blit_center(screen, small, status, (255, 80, 80), 80)

        bar_w, bar_h = int(sw * 0.4), 12
        bar_x, bar_y = (sw - bar_w) // 2, sh - 50
        pygame.draw.rect(screen, (60, 60, 60), (bar_x, bar_y, bar_w, bar_h))
        pygame.draw.rect(screen, (0, 200, 90),
                         (bar_x, bar_y, int(bar_w * len(samples) / SAMPLES_PER_POINT), bar_h))
        pygame.display.flip()

    return samples


def run_calibration(cap, extractor, ear_threshold, auto_start=False):
    pygame.init()
    try:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        pygame.display.set_caption("Gaze calibration")
        pygame.mouse.set_visible(False)
        sw, sh = screen.get_size()
        big, small = pygame.font.Font(None, 64), pygame.font.Font(None, 34)

        points = build_points(sw, sh)
        X, Y, G = [], [], []
        if not auto_start:
            wait_for_space(screen, big, small)
        for i, (px, py) in enumerate(points):
            samples = collect_point(screen, small, cap, extractor, ear_threshold,
                                    (px, py), i, len(points))
            X.extend(samples)
            Y.extend([(px, py)] * len(samples))
            G.extend([i] * len(samples))
    finally:
        pygame.quit()
    return (np.array(X, dtype=np.float64), np.array(Y, dtype=np.float64),
            np.array(G), sw, sh)


def new_regressor() -> MLPRegressor:
    # Small, strongly L2-regularised network: with only 9 distinct targets a big
    # network memorises them and behaves randomly in between.
    return MLPRegressor(hidden_layer_sizes=(16,), activation="tanh", solver="adam",
                        alpha=1e-2, learning_rate_init=2e-3, max_iter=1500,
                        n_iter_no_change=60, tol=1e-6, random_state=42)


NOISE_SIGMA = 0.15   # input noise (in standardised units) added during training
NOISE_COPIES = 15    # noisy copies of every sample


def fit_model(Xs, Yn) -> MLPRegressor:
    """Train on noise-augmented inputs so the learned map is smooth: the network
    learns to ignore small per-frame landmark jitter instead of amplifying it."""
    rng = np.random.default_rng(0)
    Xa = np.vstack([Xs] + [Xs + rng.normal(0, NOISE_SIGMA, Xs.shape)
                           for _ in range(NOISE_COPIES)])
    Ya = np.vstack([Yn] * (NOISE_COPIES + 1))
    return gc.HybridGazeModel().fit(Xa, Ya)


def train_and_save(X, Y, groups, sw, sh, camera_size, out_path) -> None:
    # Standardise inputs: raw bbox values barely vary (~0.01-0.1), which stalls
    # MLP training. Targets are scaled to 0..1 for the same reason.
    x_scaler = StandardScaler().fit(X)
    Xs = x_scaler.transform(X)
    Yn = Y / np.array([sw, sh])

    spread = X.max(axis=0) - X.min(axis=0)
    if spread.max() < 0.06:
        print("WARNING: your head barely moved between points (feature range "
              f"{spread.round(3)}, want at least 0.06). The cursor WILL be jittery. "
              "Re-run and exaggerate the head turns and leaning toward each dot.")

    # Quick sanity check: hold out the last frames of every point, train on the rest.
    val = np.zeros(len(X), dtype=bool)
    for g in np.unique(groups):
        val[np.where(groups == g)[0][-HOLDOUT_PER_POINT:]] = True
    check = fit_model(Xs[~val], Yn[~val])
    err = np.linalg.norm((check.predict(Xs[val]) - Yn[val]) * np.array([sw, sh]), axis=1)
    print(f"Held-out-frame error: mean {err.mean():.0f}px, median {np.median(err):.0f}px "
          "(same dots, unseen frames - optimistic vs. real use)")

    # Final model on ALL frames.
    model = fit_model(Xs, Yn)
    train_err = np.linalg.norm((model.predict(Xs) - Yn) * np.array([sw, sh]), axis=1)
    print(f"Final model training error: mean {train_err.mean():.0f}px "
          f"({model.n_iter_} iterations)")

    joblib.dump({"model": model, "x_scaler": x_scaler, "screen_w": sw, "screen_h": sh,
                 "feature_names": gc.FEATURE_NAMES,
                 "camera_size": camera_size,
                 "z_lo": Xs.min(axis=0) - 0.5, "z_hi": Xs.max(axis=0) + 0.5}, out_path)
    print(f"Saved model -> {out_path}")


def main() -> None:
    ap = argparse.ArgumentParser(description="9-point gaze calibration")
    ap.add_argument("--camera", type=int, default=gc.CAMERA_INDEX)
    ap.add_argument("--ear-threshold", type=float, default=gc.EAR_THRESHOLD)
    ap.add_argument("--output", default=str(gc.MODEL_PATH))
    ap.add_argument("--grid", type=int, default=3, help="3 = 9 points, 4 = 16 points")
    ap.add_argument("--auto-start", action="store_true",
                    help="begin the prompted calibration immediately without waiting for SPACE")
    args = ap.parse_args()
    global GRID_N
    GRID_N = max(2, args.grid)

    make_dpi_aware()
    try:
        cap = gc.open_camera(args.camera)
    except gc.CameraError as exc:
        print(f"ERROR: {exc}")
        sys.exit(1)

    data_path = Path(args.output).with_name("gaze_data.npz")
    print("Existing valid gesture calibrations will be kept.")

    camera_size = gc.camera_frame_size(cap)
    print(f"Camera capture mode: {camera_size[0]}x{camera_size[1]}")
    extractor = gc.FaceFeatureExtractor()
    try:
        X, Y, G, sw, sh = run_calibration(
            cap, extractor, args.ear_threshold, auto_start=args.auto_start
        )
    except CalibrationAborted:
        print("Calibration aborted; nothing saved.")
        sys.exit(1)
    except gc.CameraError as exc:
        print(f"ERROR: {exc}")
        sys.exit(1)
    finally:
        cap.release()
        extractor.close()

    np.savez(data_path, X=X, Y=Y, G=G, sw=sw, sh=sh, camera_size=camera_size)

    print(f"Collected {len(X)} samples across {len(np.unique(G))} point-sessions "
          f"(screen {sw}x{sh}). Training...")
    train_and_save(X, Y, G, sw, sh, camera_size, args.output)


if __name__ == "__main__":
    main()
