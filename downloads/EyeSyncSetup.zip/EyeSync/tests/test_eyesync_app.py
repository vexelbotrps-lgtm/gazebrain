import unittest
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import Mock, call, patch
from pathlib import Path

from eyesync_app import CALIBRATION_STEPS, run_calibration_sequence
import setup_and_start
import quick_setup
import calibrate_tab
import gaze_core as gc
from quick_setup import find_python


class CalibrationSequenceTests(unittest.TestCase):
    def test_setup_selects_latest_installed_python_supported_by_dependencies(self):
        def run(command, **_kwargs):
            if command == ["py", "-0"]:
                return SimpleNamespace(
                    returncode=0,
                    stdout=(
                        " -V:3.12 * C:\\Python312\\python.exe\n"
                        " -3.15-64 C:\\Python315\\python.exe\n"
                    ),
                    stderr="",
                )
            version = command[1]
            return SimpleNamespace(
                returncode=0,
                stdout=f"Python {version[1:]}.0\n",
                stderr="",
            )

        with (
            patch("quick_setup.shutil.which", side_effect=lambda name: "py.exe" if name == "py" else None),
            patch("quick_setup.subprocess.run", side_effect=run),
        ):
            self.assertEqual(find_python(), ["py", "-3.12"])

    def test_setup_rebuilds_old_virtual_environment_with_newest_python(self):
        with tempfile.TemporaryDirectory() as temporary:
            venv_dir = Path(temporary) / ".venv"
            python_path = venv_dir / "Scripts" / "python.exe"
            python_path.parent.mkdir(parents=True)
            python_path.touch()

            def run(command, **_kwargs):
                if command == ["py", "-3.12", "--version"]:
                    return SimpleNamespace(returncode=0, stdout="Python 3.12.11", stderr="")
                if command == [str(python_path), "--version"]:
                    return SimpleNamespace(returncode=0, stdout="Python 3.12.10", stderr="")
                return SimpleNamespace(returncode=0, stdout="", stderr="")

            with (
                patch.object(quick_setup, "VENV_DIR", venv_dir),
                patch("quick_setup.subprocess.run", side_effect=run) as run_process,
            ):
                self.assertEqual(
                    quick_setup.ensure_venv(["py", "-3.12"]),
                    python_path,
                )

            self.assertIn(
                call(
                    ["py", "-3.12", "-m", "venv", "--clear", str(venv_dir)],
                    check=True,
                ),
                run_process.call_args_list,
            )

    def test_prepare_only_installs_dependencies_without_launching_app(self):
        with (
            patch("quick_setup.prepare_environment", return_value=Path("python.exe")),
            patch("quick_setup.subprocess.Popen") as launch,
        ):
            self.assertEqual(quick_setup.main(["--prepare-only"]), 0)

        launch.assert_not_called()

    def test_command_line_start_does_not_run_calibration_by_default(self):
        with (
            patch.object(sys, "argv", ["setup_and_start.py"]),
            patch("setup_and_start.start_tracker", return_value=0) as start_tracker,
            patch("setup_and_start.missing_calibrations") as missing_calibrations,
            patch("setup_and_start.missing_sample_collections") as missing_samples,
            patch("setup_and_start.missing_tab_calibration") as missing_tab,
        ):
            self.assertEqual(setup_and_start.main(), 0)

        start_tracker.assert_called_once_with()
        missing_calibrations.assert_not_called()
        missing_samples.assert_not_called()
        missing_tab.assert_not_called()

    def test_runs_all_steps_in_order_only_after_success(self):
        run_step = Mock(return_value=SimpleNamespace(returncode=0, stdout="", stderr=""))
        validate = Mock(return_value=True)
        report = Mock()

        self.assertTrue(run_calibration_sequence(run_step, validate, report))

        self.assertEqual(
            run_step.call_args_list,
            [call(script, arguments) for _, script, arguments, _ in CALIBRATION_STEPS],
        )
        self.assertEqual(
            validate.call_args_list,
            [call(key) for _, _, _, key in CALIBRATION_STEPS],
        )

    def test_nonzero_step_stops_later_calibrations(self):
        run_step = Mock(
            side_effect=[
                SimpleNamespace(returncode=1, stdout="failed", stderr=""),
            ]
        )
        validate = Mock(return_value=True)

        self.assertFalse(run_calibration_sequence(run_step, validate, Mock()))

        run_step.assert_called_once_with(
            CALIBRATION_STEPS[0][1], CALIBRATION_STEPS[0][2]
        )
        validate.assert_not_called()

    def test_invalid_result_stops_later_calibrations(self):
        run_step = Mock(return_value=SimpleNamespace(returncode=0, stdout="", stderr=""))
        validate = Mock(return_value=False)

        self.assertFalse(run_calibration_sequence(run_step, validate, Mock()))

        run_step.assert_called_once_with(
            CALIBRATION_STEPS[0][1], CALIBRATION_STEPS[0][2]
        )
        validate.assert_called_once_with(CALIBRATION_STEPS[0][3])

    def test_calibration_sequence_includes_both_eyes_closed_tab_step(self):
        self.assertEqual(
            CALIBRATION_STEPS[-1],
            ("Both-eyes-closed Tab calibration", "calibrate_tab.py", (), "tab"),
        )

    def test_tab_profile_thresholds_separate_open_and_closed_eyes(self):
        samples = {
            "open": {
                "left": [0.30] * calibrate_tab.MIN_SAMPLES,
                "right": [0.32] * calibrate_tab.MIN_SAMPLES,
            },
            "closed": {
                "left": [0.12] * calibrate_tab.MIN_SAMPLES,
                "right": [0.13] * calibrate_tab.MIN_SAMPLES,
            },
        }

        profile = calibrate_tab.build_profile(samples)

        self.assertLess(profile["close_ratio_left"], profile["open_ratio_left"])
        self.assertLess(profile["close_ratio_right"], profile["open_ratio_right"])
        self.assertIsNotNone(gc.load_tab_profile_from_data(profile))

    def test_tab_profile_is_saved_and_loaded_from_its_local_file(self):
        samples = {
            "open": {
                "left": [0.30] * calibrate_tab.MIN_SAMPLES,
                "right": [0.32] * calibrate_tab.MIN_SAMPLES,
            },
            "closed": {
                "left": [0.12] * calibrate_tab.MIN_SAMPLES,
                "right": [0.13] * calibrate_tab.MIN_SAMPLES,
            },
        }
        with tempfile.TemporaryDirectory() as temporary:
            profile_path = Path(temporary) / "tab_profile.json"
            with patch.object(gc, "TAB_PROFILE_PATH", profile_path):
                calibrate_tab.save_profile(calibrate_tab.build_profile(samples))
                loaded = gc.load_tab_profile(profile_path)

        self.assertIsNotNone(loaded)
        self.assertEqual(loaded["version"], gc.TAB_PROFILE_VERSION)

    def test_tab_profile_rejects_overlapping_open_and_closed_measurements(self):
        samples = {
            "open": {"left": [0.30] * 25, "right": [0.32] * 25},
            "closed": {"left": [0.29] * 25, "right": [0.31] * 25},
        }

        with self.assertRaisesRegex(ValueError, "overlap too much"):
            calibrate_tab.build_profile(samples)


if __name__ == "__main__":
    unittest.main()
