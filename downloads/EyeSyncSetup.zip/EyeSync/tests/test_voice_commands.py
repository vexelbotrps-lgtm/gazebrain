import asyncio
import ctypes
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, call, patch

import gaze_core as gc
import numpy as np
import voice_commands as vc
import live


class VoiceCommandParsingTests(unittest.TestCase):
    def test_windows_input_union_is_large_enough_for_native_input(self):
        self.assertGreaterEqual(
            ctypes.sizeof(vc._Input),
            ctypes.sizeof(ctypes.c_void_p) * 5,
        )

    def test_recognizes_requested_commands(self):
        cases = {
            "Open the on screen keyboard": "open_keyboard",
            "close the on-screen keyboard": "close_keyboard",
            "Let me adjust the position of the on screen keyboard": "start_adjusting",
            "Done adjusting the position of the on-screen keyboard": "stop_adjusting",
            "increase the size of the on screen keyboard": "increase_keyboard",
            "decrease the size of the on screen keyboard": "reduce_keyboard",
        }
        for phrase, expected in cases.items():
            with self.subTest(phrase=phrase):
                self.assertEqual(vc.command_action(phrase), expected)

    def test_only_requested_commands_are_supported(self):
        cases = {
            "open the on-screen keyboard": "open_keyboard",
            "close the on-screen keyboard": "close_keyboard",
            "increase the size of the on screen keyboard": "increase_keyboard",
            "decrease the size of the on-screen keyboard": "reduce_keyboard",
            "let me adjust the position of the on-screen keyboard": "start_adjusting",
            "done adjusting the position of the on-screen keyboard": "stop_adjusting",
            "open on-screen keyboard": None,
            "done adjusting": None,
            "move command box left": None,
            "let me adjust the position of the command box": None,
            "done adjusting the position of the command box": None,
            "increase the size of the command box": None,
            "decrease the size of the command box": None,
            "start listening": None,
            "delete all files": None,
        }
        for phrase, expected in cases.items():
            with self.subTest(phrase=phrase):
                self.assertEqual(vc.wispr_command_action(phrase), expected)

    @staticmethod
    def make_ready_tab_detector():
        detector = gc.BilateralEyeClosureDetector()
        for _ in range(detector.BASELINE_SAMPLES):
            detector.update(0.30, 0.32, now=1.0)
        return detector

    def test_one_second_bilateral_eye_closure_toggles_and_rearms(self):
        detector = self.make_ready_tab_detector()
        self.assertTrue(detector.ready)
        self.assertFalse(detector.update(0.10, 0.10, now=2.0))
        self.assertFalse(detector.update(0.10, 0.10, now=2.99))
        self.assertTrue(detector.update(0.10, 0.10, now=3.01))
        self.assertTrue(detector.active)
        self.assertTrue(detector.awaiting_reopen)
        self.assertFalse(detector.update(0.10, 0.10, now=3.1))
        self.assertFalse(detector.update(0.30, 0.32, now=4.0))
        self.assertFalse(detector.update(0.30, 0.32, now=4.24))
        self.assertFalse(detector.update(0.30, 0.32, now=4.26))
        self.assertFalse(detector.active)
        self.assertFalse(detector.awaiting_reopen)
        self.assertFalse(detector.update(0.10, 0.10, now=5.0))
        self.assertTrue(detector.update(0.10, 0.10, now=6.01))

    def test_face_loss_cancels_hold_but_keeps_trigger_latched(self):
        detector = self.make_ready_tab_detector()
        self.assertFalse(detector.update(0.10, 0.10, now=2.0))
        detector.cancel_hold()
        self.assertFalse(detector.update(0.10, 0.10, now=3.0))
        self.assertTrue(detector.update(0.10, 0.10, now=4.0))
        detector.cancel_hold()
        self.assertFalse(detector.update(0.30, 0.32, now=5.0))
        self.assertFalse(detector.update(0.30, 0.32, now=5.26))
        self.assertFalse(detector.update(0.10, 0.10, now=6.0))

    def test_bilateral_eye_hold_tolerates_brief_classification_jitter(self):
        detector = self.make_ready_tab_detector()
        self.assertFalse(detector.update(0.10, 0.10, now=2.0))
        self.assertFalse(detector.update(0.30, 0.10, now=2.3))
        self.assertFalse(detector.update(0.10, 0.10, now=2.39))
        self.assertTrue(detector.update(0.10, 0.10, now=3.0))

    def test_long_one_eye_open_gap_restarts_the_hold(self):
        detector = self.make_ready_tab_detector()
        self.assertFalse(detector.update(0.10, 0.10, now=2.0))
        self.assertFalse(detector.update(0.30, 0.10, now=2.3))
        self.assertFalse(detector.update(0.30, 0.10, now=2.51))
        self.assertFalse(detector.update(0.10, 0.10, now=2.6))
        self.assertFalse(detector.update(0.10, 0.10, now=3.59))
        self.assertTrue(detector.update(0.10, 0.10, now=3.61))

    def test_one_eye_closure_does_not_trigger_tab(self):
        detector = self.make_ready_tab_detector()
        self.assertFalse(detector.update(0.10, 0.32, now=2.0))
        self.assertFalse(detector.update(0.10, 0.32, now=3.5))
        self.assertFalse(detector.active)

    def test_open_eye_variation_does_not_start_bilateral_closure(self):
        detector = self.make_ready_tab_detector()
        self.assertFalse(detector.update(0.264, 0.2816, now=2.0))
        self.assertFalse(detector.update(0.264, 0.2816, now=3.5))
        self.assertFalse(detector.active)

    def test_moderate_eye_closure_ratio_starts_bilateral_closure(self):
        detector = self.make_ready_tab_detector()
        self.assertFalse(detector.update(0.2475, 0.264, now=2.0))
        self.assertTrue(detector.active)

    def test_short_bilateral_eye_closure_does_not_tap_tab(self):
        detector = self.make_ready_tab_detector()
        self.assertFalse(detector.update(0.10, 0.10, now=2.0))
        self.assertFalse(detector.update(0.30, 0.32, now=2.2))
        self.assertFalse(detector.active)
        self.assertFalse(detector.update(0.10, 0.10, now=2.3))
        self.assertFalse(detector.update(0.10, 0.10, now=3.29))

    def test_detector_learns_open_eye_baselines(self):
        detector = gc.BilateralEyeClosureDetector()
        for _ in range(detector.BASELINE_SAMPLES):
            detector.update(0.15, 0.16, now=1.0)
        self.assertAlmostEqual(detector.baseline_ears[0], 0.15)
        self.assertAlmostEqual(detector.baseline_ears[1], 0.16)
        self.assertFalse(detector.update(0.08, 0.08, now=2.0))
        self.assertTrue(detector.update(0.08, 0.08, now=3.01))

    def test_tab_detector_uses_personalized_closed_eye_thresholds(self):
        profile = {
            "close_ratio_left": 0.60,
            "open_ratio_left": 0.80,
            "close_ratio_right": 0.62,
            "open_ratio_right": 0.82,
        }
        detector = gc.BilateralEyeClosureDetector(profile)
        for _ in range(detector.BASELINE_SAMPLES):
            detector.update(0.30, 0.32, now=1.0)

        self.assertFalse(detector.update(0.21, 0.22, now=2.0))
        self.assertFalse(detector.active)
        self.assertFalse(detector.update(0.15, 0.16, now=3.0))
        self.assertTrue(detector.update(0.15, 0.16, now=4.01))

    def test_closed_eyes_at_start_do_not_become_open_eye_baseline(self):
        detector = gc.BilateralEyeClosureDetector()
        for _ in range(detector.BASELINE_SAMPLES):
            detector.update(0.03, 0.04, now=1.0)
        self.assertFalse(detector.ready)
        for _ in range(detector.BASELINE_SAMPLES):
            detector.update(0.15, 0.16, now=2.0)
        self.assertTrue(detector.ready)

    def test_camera_frame_loss_cancels_in_progress_eye_closure(self):
        pipeline = live.VisionPipeline.__new__(live.VisionPipeline)
        pipeline.cap = Mock()
        pipeline.cap.read.return_value = (False, None)
        pipeline.eye_closure = Mock()
        pipeline.failed_reads = 0
        pipeline.last_xy = None
        pipeline.cursor_gesture_active = False
        with patch("live.time.sleep"):
            result = pipeline.step()
        pipeline.eye_closure.cancel_hold.assert_called_once_with()
        self.assertFalse(result.tab_key_tap)

    def test_cursor_is_frozen_for_gesture_and_reseeds_before_resuming(self):
        pipeline = live.VisionPipeline.__new__(live.VisionPipeline)
        pipeline.cap = Mock()
        pipeline.cap.read.return_value = (True, object())
        pipeline.extractor = Mock()
        pipeline.extractor.process.return_value = SimpleNamespace(
            smile_features=np.array([0.50, 0.03, 0.0, 0.0, 0.0]),
            ear_left=0.10,
            ear_right=0.10,
            features=np.zeros(4),
        )
        pipeline.eye_closure = Mock()
        pipeline.eye_closure.update.return_value = False
        pipeline.eye_closure.active = True
        pipeline.eye_closure.last_left = 1.0
        pipeline.eye_closure.last_right = 1.0
        pipeline.eye_closure.hold_progress = 0.2
        pipeline.smile_click = Mock()
        pipeline.smile_click.active = False
        pipeline.smile_click.update.return_value = False
        pipeline.smile_click.last_ratio = 1.0
        pipeline.smile_click.hold_progress = 0.0
        pipeline.mouth_click = Mock()
        pipeline.mouth_click.active = False
        pipeline.mouth_click.update.return_value = False
        pipeline.mouth_click.open_threshold = 0.2
        pipeline.mouth_click.release_threshold = 0.1
        pipeline.mouth_click.hold_progress = 0.0
        pipeline.mouth_click.HOLD_S = gc.MouthOpenClickDetector.HOLD_S
        pipeline.enable_click_gestures = True
        pipeline.right_click_enabled = True
        pipeline.args = SimpleNamespace(
            alpha=0.35, min_cutoff=1.2, beta=0.004, preview=False
        )
        pipeline.bundle = {}
        pipeline.feat_ema = Mock()
        pipeline.smoother = Mock()
        pipeline.last_xy = (100.0, 200.0)
        pipeline.cursor_gesture_active = False
        pipeline.failed_reads = 0

        with patch("live.gc.predict_xy", return_value=(120.0, 220.0)) as predict_xy:
            gesture_result = pipeline.step()
            pipeline.eye_closure.update.assert_called_once_with(0.10, 0.10)
            self.assertEqual(gesture_result.xy, (100.0, 200.0))
            self.assertTrue(gesture_result.cursor_frozen)
            pipeline.eye_closure.active = False
            release_result = pipeline.step()
            self.assertEqual(release_result.xy, (100.0, 200.0))
            self.assertFalse(release_result.cursor_frozen)
            predict_xy.assert_not_called()
            resumed_result = pipeline.step()
            self.assertFalse(resumed_result.cursor_frozen)
            predict_xy.assert_called_once()

    def test_mouse_loop_does_not_move_cursor_while_gesture_is_active(self):
        async def run_once():
            stop = asyncio.Event()

            class StopAfterOneTick:
                async def wait(self):
                    stop.set()

            state = live.SharedState(
                x=100.0,
                y=200.0,
                has_position=True,
                mouse_enabled=True,
                cursor_frozen=True,
                face_seen_at=live.time.monotonic(),
            )
            with (
                patch("live.LocalMouseController") as mouse_factory,
                patch("live.Ticker", return_value=StopAfterOneTick()),
                patch("live.hotkey_kill_pressed", return_value=False),
            ):
                await live.mouse_loop(
                    SimpleNamespace(deadzone=1), state, stop
                )
            mouse_factory.return_value.move.assert_not_called()

        asyncio.run(run_once())

    def test_tab_injects_key_down_and_key_up(self):
        sent = []
        fake_user32 = Mock()
        fake_user32.SendInput.side_effect = lambda count, pointer, _size: (
            sent.append((pointer._obj.ki.wVk, pointer._obj.ki.dwFlags)) or count
        )
        with (
            patch("voice_commands.sys.platform", "win32"),
            patch("voice_commands.ctypes.WinDLL", return_value=fake_user32),
        ):
            vc.set_tab_key_down(True)
            vc.set_tab_key_down(False)
        self.assertEqual(sent, [(0x09, 0), (0x09, 0x0002)])

    def test_bilateral_eye_gesture_sends_one_tab_tap_and_beeps_on_press(self):
        state = live.SharedState()
        events = []
        with (
            patch(
                "live.vc.set_tab_key_down",
                side_effect=lambda down: events.append(
                    "down" if down else "up"
                ),
            ) as set_key,
            patch(
                "live.vc.play_tab_confirmation",
                side_effect=lambda: events.append("beep"),
            ) as confirmation,
        ):
            self.assertTrue(live.tap_tab_key(state))
        self.assertEqual(set_key.call_args_list, [call(True), call(False)])
        self.assertEqual(events, ["down", "beep", "up"])
        self.assertFalse(state.tab_key_held)
        self.assertEqual(state.tab_key_retry_at, 0.0)
        confirmation.assert_called_once_with()

    def test_failed_tab_tap_release_is_retried(self):
        state = live.SharedState()
        with (
            patch("live.vc.set_tab_key_down", side_effect=[None, OSError("blocked")])
            as set_key,
            patch("live.vc.play_tab_confirmation") as confirmation,
            self.assertLogs("gaze", level="ERROR"),
        ):
            self.assertFalse(live.tap_tab_key(state))
        self.assertEqual(set_key.call_args_list, [call(True), call(False)])
        self.assertTrue(state.tab_key_held)
        self.assertGreater(state.tab_key_retry_at, 0.0)
        confirmation.assert_called_once_with()

    def test_tab_confirmation_plays_a_rising_tone(self):
        fake_winsound = Mock()
        with (
            patch("voice_commands.sys.platform", "win32"),
            patch.dict("sys.modules", {"winsound": fake_winsound}),
        ):
            self.assertTrue(vc.play_tab_confirmation())
        self.assertEqual(
            fake_winsound.Beep.call_args_list,
            [call(1480, 100)],
        )

    def test_tab_confirmation_sound_failure_does_not_raise(self):
        fake_winsound = Mock()
        fake_winsound.Beep.side_effect = RuntimeError("audio unavailable")
        with (
            patch("voice_commands.sys.platform", "win32"),
            patch.dict("sys.modules", {"winsound": fake_winsound}),
            self.assertLogs("gaze.voice", level="WARNING"),
        ):
            self.assertFalse(vc.play_tab_confirmation())

    def test_osk_launch_uses_shell_execute_with_explicit_elevation(self):
        shell32 = Mock()
        shell32.ShellExecuteW.return_value = 33
        with (
            patch("voice_commands.sys.platform", "win32"),
            patch("voice_commands.ctypes.WinDLL", return_value=shell32),
            patch("voice_commands._get_osk_window", return_value=0),
            patch("voice_commands.Path.is_file", return_value=True),
            patch.dict("voice_commands.os.environ", {"WINDIR": r"C:\Windows"}),
        ):
            self.assertTrue(vc.open_onscreen_keyboard())
        args = shell32.ShellExecuteW.call_args.args
        self.assertEqual(args[1], "runas")
        self.assertEqual(args[2], r"C:\Windows\System32\osk.exe")

    def test_osk_launch_failure_is_reported(self):
        shell32 = Mock()
        shell32.ShellExecuteW.return_value = 5
        with (
            patch("voice_commands.sys.platform", "win32"),
            patch("voice_commands.ctypes.WinDLL", return_value=shell32),
            patch("voice_commands._get_osk_window", return_value=0),
            patch("voice_commands.Path.is_file", return_value=True),
            patch.dict("voice_commands.os.environ", {"WINDIR": r"C:\Windows"}),
        ):
            with self.assertRaisesRegex(OSError, "Windows could not start"):
                vc.open_onscreen_keyboard()

    def test_osk_shell_execute_success_value_740_is_not_a_winerror(self):
        shell32 = Mock()
        shell32.ShellExecuteW.return_value = 740
        with (
            patch("voice_commands.sys.platform", "win32"),
            patch("voice_commands.ctypes.WinDLL", return_value=shell32),
            patch("voice_commands._get_osk_window", return_value=0),
            patch("voice_commands.Path.is_file", return_value=True),
            patch.dict("voice_commands.os.environ", {"WINDIR": r"C:\Windows"}),
        ):
            self.assertTrue(vc.open_onscreen_keyboard())

    def test_detects_numeric_expressions_for_osk_entry(self):
        for phrase in (
            "twelve plus seven",
            "144 divided by 12",
            "negative 2.5 times 4",
            "my number is 12345",
            "two hundred and six",
        ):
            with self.subTest(phrase=phrase):
                self.assertTrue(vc.contains_numeric_expression(phrase))

    def test_allows_non_numeric_dictation(self):
        self.assertFalse(
            vc.contains_numeric_expression("Please open the blue folder")
        )

    def test_types_unicode_as_sendinput_unicode_events(self):
        captured = {}

        def send_input(count, input_array, _size):
            captured["events"] = [
                (
                    input_array[index].ki.wScan,
                    input_array[index].ki.dwFlags,
                )
                for index in range(count)
            ]
            return count

        fake_user32 = Mock()
        fake_user32.SendInput.side_effect = send_input

        with (
            patch("voice_commands.sys.platform", "win32"),
            patch("voice_commands.ctypes.WinDLL", return_value=fake_user32),
        ):
            vc.type_text("Aé")

        self.assertEqual(
            captured["events"],
            [
                (ord("A"), 0x0004), (ord("A"), 0x0006),
                (ord("é"), 0x0004), (ord("é"), 0x0006),
            ],
        )


if __name__ == "__main__":
    unittest.main()
