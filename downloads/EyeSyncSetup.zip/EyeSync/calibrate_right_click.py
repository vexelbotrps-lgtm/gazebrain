"""Collect eye-closure measurements and optionally build a legacy eye profile.

Only eye-aspect-ratio samples and pose references are retained; no images/video
are saved. Current right-click uses a sustained mouth-open gesture instead.
"""
from __future__ import annotations

import argparse
import json
import sys
import time

import cv2
import numpy as np

import gaze_core as gc

POSES = (
    ("center", "face the camera"),
    ("down", "tilt your head down"),
    ("left", "turn slightly left"),
    ("right", "turn slightly right"),
)
EXPRESSIONS = (
    ("open", "Keep both eyes comfortably open"),
    ("wink_left", "Close your left eye; keep the right eye comfortably open"),
    ("wink_right", "Close your right eye; keep the left eye comfortably open"),
)
READY_SECONDS = 5.0
SAMPLE_SECONDS = 5.0
SAMPLE_INTERVAL_S = 0.12
MIN_SAMPLES = 25
MIN_SEPARATION = 0.08
SAMPLES_PATH = gc.BLINK_PROFILE_PATH.with_name("wink_samples.npz")
SAMPLE_ARCHIVE_VERSION = 1


def run(camera: int) -> dict[str, dict[str, np.ndarray]]:
    cap = gc.open_camera(camera)
    extractor = gc.FaceFeatureExtractor()
    samples: dict[str, dict[str, list[float]]] = {}
    for pose, _ in POSES:
        for expression, _ in EXPRESSIONS:
            samples[f"{expression}_{pose}"] = {
                "left": [], "right": [], "pose": [], "yaw": [],
            }

    window = "wink sample collection (legacy eye profile)"
    try:
        for pose, pose_instruction in POSES:
            for expression, expression_instruction in EXPRESSIONS:
                key = f"{expression}_{pose}"
                instruction = f"{expression_instruction}; {pose_instruction}"
                started = time.monotonic()
                last_sample = float("-inf")
                while True:
                    elapsed = time.monotonic() - started
                    if elapsed >= READY_SECONDS + SAMPLE_SECONDS:
                        break
                    ok, frame = cap.read()
                    if not ok or frame is None:
                        raise gc.CameraError(
                            f"Camera stopped delivering frames during '{key}'."
                        )
                    result = extractor.process(frame)
                    recording = elapsed >= READY_SECONDS
                    if (recording and result is not None
                            and elapsed - last_sample >= SAMPLE_INTERVAL_S):
                        values = samples[key]
                        values["left"].append(float(result.ear_left))
                        values["right"].append(float(result.ear_right))
                        values["pose"].append(float(result.smile_features[2]))
                        values["yaw"].append(float(result.smile_features[4]))
                        last_sample = elapsed

                    remaining = (READY_SECONDS + SAMPLE_SECONDS - elapsed
                                 if recording else READY_SECONDS - elapsed)
                    prompt = instruction if recording else f"Get ready: {instruction}"
                    cv2.rectangle(frame, (0, 0), (frame.shape[1], 75), (0, 0, 0), -1)
                    cv2.putText(frame, f"{prompt} [{remaining:.0f}s]", (8, 27),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                                (0, 255, 0) if recording else (0, 200, 255), 2)
                    message = ("Face not detected" if result is None else
                               f"EAR L/R {result.ear_left:.3f}/{result.ear_right:.3f}  "
                               f"samples {len(samples[key]['left'])}")
                    cv2.putText(frame, message, (8, 60), cv2.FONT_HERSHEY_SIMPLEX,
                                0.58, (0, 255, 255), 2)
                    cv2.imshow(window, frame)
                    if cv2.waitKey(1) & 0xFF == 27:
                        raise KeyboardInterrupt("Calibration cancelled.")
    finally:
        cap.release()
        extractor.close()
        cv2.destroyAllWindows()

    for key, values in samples.items():
        if len(values["left"]) < MIN_SAMPLES:
            raise ValueError(
                f"Only {len(values['left'])} eye samples recorded during '{key}'; "
                f"at least {MIN_SAMPLES} are required. Keep both eyes and your "
                "face visible, then retry."
            )
    return {
        key: {name: np.asarray(values, dtype=np.float64)
              for name, values in measurements.items()}
        for key, measurements in samples.items()
    }


def save_samples(samples: dict[str, dict[str, np.ndarray]]) -> None:
    archived: dict[str, np.ndarray] = {
        "version": np.asarray(SAMPLE_ARCHIVE_VERSION, dtype=np.int32)
    }
    if has_saved_samples():
        with np.load(SAMPLES_PATH, allow_pickle=False) as previous:
            archived.update({key: previous[key] for key in previous.files
                             if key != "version"})
    for phase, measurements in samples.items():
        for name, values in measurements.items():
            key = f"{phase}__{name}"
            archived[key] = (np.concatenate((archived[key], values), axis=0)
                             if key in archived else values)
    temporary = SAMPLES_PATH.with_suffix(".npz.tmp")
    with temporary.open("wb") as stream:
        np.savez_compressed(stream, **archived)
    temporary.replace(SAMPLES_PATH)


def has_saved_samples() -> bool:
    try:
        with np.load(SAMPLES_PATH, allow_pickle=False) as archive:
            if int(archive["version"]) != SAMPLE_ARCHIVE_VERSION:
                return False
            for pose, _ in POSES:
                for expression, _ in EXPRESSIONS:
                    phase = f"{expression}_{pose}"
                    for measurement in ("left", "right", "pose", "yaw"):
                        values = archive[f"{phase}__{measurement}"]
                        if (values.ndim != 1 or len(values) < MIN_SAMPLES
                                or not np.all(np.isfinite(values))):
                            return False
    except (OSError, ValueError, KeyError, TypeError):
        return False
    return True


def build_profile(samples: dict[str, dict[str, np.ndarray]]) -> dict:
    models = {}
    for pose, _ in POSES:
        opened = samples.get(f"open_{pose}")
        wink_left = samples.get(f"wink_left_{pose}")
        wink_right = samples.get(f"wink_right_{pose}")
        pose_samples = (opened, wink_left, wink_right)
        if any(values is None for values in pose_samples):
            raise ValueError(f"Open and left/right wink samples are required for {pose}.")
        if any(len(values.get(key, ())) < MIN_SAMPLES
               for values in pose_samples
               for key in ("left", "right", "pose", "yaw")):
            raise ValueError(
                f"At least {MIN_SAMPLES} open, left-wink, and right-wink samples "
                f"are required for the {pose} pose."
            )

        baselines = {}
        thresholds = {}
        for eye, wink_key in (("left", "wink_left"), ("right", "wink_right")):
            open_values = np.asarray(opened[eye], dtype=np.float64)
            closed_values = np.asarray(samples[f"{wink_key}_{pose}"][eye],
                                       dtype=np.float64)
            if not np.all(np.isfinite(open_values)) or not np.all(np.isfinite(closed_values)):
                raise ValueError(f"Non-finite eye samples were recorded for {pose}.")
            baseline = float(np.median(open_values))
            if baseline <= 1e-5:
                raise ValueError(f"Could not establish an open-eye baseline for {pose}.")
            open_floor = float(np.percentile(open_values, 10)) / baseline
            closed_ceiling = float(np.percentile(closed_values, 90)) / baseline
            separation = open_floor - closed_ceiling
            if not np.isfinite(separation) or separation < MIN_SEPARATION:
                raise ValueError(
                    f"Open and wink-closed {eye} eye samples overlap in the {pose} pose "
                    f"(open P10={open_floor:.3f}, closed P90={closed_ceiling:.3f}). "
                    "Repeat calibration with both eyes relaxed open during open steps "
                    "and that eye fully closed during its wink step."
                )
            baselines[eye] = baseline
            thresholds[eye] = (
                closed_ceiling + 0.60 * separation,
                closed_ceiling + 0.82 * separation,
            )

        models[pose] = {
            "baseline_l": baselines["left"],
            "baseline_r": baselines["right"],
            "close_l": thresholds["left"][0],
            "open_l": thresholds["left"][1],
            "close_r": thresholds["right"][0],
            "open_r": thresholds["right"][1],
            "pose": float(np.median(np.concatenate(
                [values["pose"] for values in pose_samples]
            ))),
            "yaw": float(np.median(np.concatenate(
                [values["yaw"] for values in pose_samples]
            ))),
        }
    return {"version": gc.BLINK_PROFILE_VERSION, "models": models}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Collect wink samples or build a legacy eye-closure profile"
    )
    parser.add_argument("--camera", type=int, default=gc.CAMERA_INDEX)
    parser.add_argument("--samples-only", action="store_true",
                        help="collect and save numeric wink samples without training a profile")
    args = parser.parse_args()
    try:
        samples = run(args.camera)
        save_samples(samples)
        print(f"Saved and retained numeric wink samples at {SAMPLES_PATH}")
        if args.samples_only:
            return
        profile = build_profile(samples)
    except (gc.CameraError, ValueError, KeyboardInterrupt) as exc:
        sys.exit(str(exc))

    gc.BLINK_PROFILE_PATH.write_text(json.dumps(profile, indent=2), encoding="utf-8")
    print("Saved personalized eye-closure calibration to", gc.BLINK_PROFILE_PATH)
    print("Note: current right-click uses the sustained mouth-open gesture.")


if __name__ == "__main__":
    main()
