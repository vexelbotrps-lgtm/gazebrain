"""Local command field for executing allow-listed phrases dictated with Wispr Flow."""
from __future__ import annotations

import argparse
import json
import queue
import threading
import tkinter as tk
from tkinter import ttk

from websockets.exceptions import ConnectionClosed
from websockets.sync.client import connect

import voice_commands as vc


class WisprCommandPanel:
    DEBOUNCE_MS = 1200

    def __init__(self, root: tk.Tk, uri: str) -> None:
        self.root = root
        self.uri = uri
        self.commands: queue.Queue[str] = queue.Queue()
        self.events: queue.Queue[tuple[str, str]] = queue.Queue()
        self.stopping = threading.Event()
        self.pending_after: str | None = None
        self.connected = False
        self._app_icon = self.create_app_icon()

        root.title("EyeSync Command Panel")
        root.iconphoto(True, self._app_icon)
        root.protocol("WM_DELETE_WINDOW", self.close)

        frame = ttk.Frame(root, padding=16)
        frame.pack(fill="both", expand=True)
        gesture_frame = ttk.LabelFrame(
            frame, text="Tab push-to-talk gesture for Handy AI", padding=10
        )
        gesture_frame.pack(fill="x", pady=(0, 12))
        ttk.Label(
            gesture_frame,
            text=(
                "Set Handy AI's push-to-talk shortcut to Tab. Keep your face "
                "about 60–70 cm from the webcam and look toward it with both "
                "eyes open while EyeSync learns your personal baseline. Then "
                "close both eyes clearly for 1 second to tap Tab; ordinary "
                "small eye-ratio changes do not count. Reopen for 0.25 seconds "
                "before repeating. A beep confirms the Tab press."
            ),
            wraplength=540,
        ).pack(anchor="w")
        self.gesture_status = tk.StringVar(
            value="Waiting for EyeSync eye-baseline status…"
        )
        ttk.Label(
            gesture_frame, textvariable=self.gesture_status, wraplength=540
        ).pack(anchor="w", pady=(8, 0))

        ttk.Label(
            frame,
            text="Dictate an on-screen keyboard command",
            font=("Segoe UI", 14, "bold"),
        ).pack(anchor="w")
        ttk.Label(
            frame,
            text=(
                "Click the command field, dictate with your speech tool, then pause. Only an exact "
                "supported command runs; other dictated text is not acted on."
            ),
            wraplength=520,
        ).pack(anchor="w", pady=(8, 12))

        self.command_text = tk.StringVar()
        self.entry = ttk.Entry(frame, textvariable=self.command_text, font=("Segoe UI", 12))
        self.entry.pack(fill="x")
        self.entry.bind("<Return>", self.run_now)
        self.command_text.trace_add("write", self.schedule_command)

        ttk.Button(frame, text="Run command now", command=self.run_now).pack(
            anchor="e", pady=(8, 12)
        )
        ttk.Label(
            frame,
            text=(
                "Open the on-screen keyboard · Close the on-screen keyboard\n"
                "Increase the size of the on-screen keyboard\n"
                "Decrease the size of the on-screen keyboard\n"
                "Let me adjust the position of the on-screen keyboard\n"
                "Done adjusting the position of the on-screen keyboard"
            ),
            wraplength=520,
        ).pack(anchor="w")

        self.status_text = tk.StringVar(value="Connecting to EyeSync…")
        ttk.Label(frame, textvariable=self.status_text, wraplength=520).pack(
            anchor="w", pady=(14, 0)
        )

        root.update_idletasks()
        self.minimum_width = max(420, frame.winfo_reqwidth())
        self.minimum_height = max(320, frame.winfo_reqheight())
        root.minsize(self.minimum_width, self.minimum_height)
        root.geometry(
            f"{max(600, self.minimum_width)}x{max(440, self.minimum_height)}"
        )
        threading.Thread(target=self.network_worker, daemon=True).start()
        self.root.after(150, self.poll_events)
        self.entry.focus_set()

    def schedule_command(self, *_args) -> None:
        if self.pending_after is not None:
            self.root.after_cancel(self.pending_after)
            self.pending_after = None
        phrase = self.command_text.get()
        if vc.wispr_command_action(phrase) is not None:
            self.pending_after = self.root.after(
                self.DEBOUNCE_MS, self.submit_command
            )

    def run_now(self, _event=None) -> str:
        if self.pending_after is not None:
            self.root.after_cancel(self.pending_after)
            self.pending_after = None
        self.submit_command()
        return "break"

    def submit_command(self) -> None:
        self.pending_after = None
        phrase = self.command_text.get().strip()
        if vc.wispr_command_action(phrase) is None:
            self.status_text.set(
                "No supported command matched. Nothing was done; try one of the listed phrases."
            )
            return
        action = vc.wispr_command_action(phrase)
        if not self.connected:
            self.status_text.set("EyeSync is not connected. Waiting to reconnect.")
            return
        self.commands.put(phrase)
        self.command_text.set("")
        self.status_text.set("Sending command…")

    @staticmethod
    def create_app_icon() -> tk.PhotoImage:
        image = tk.PhotoImage(width=48, height=48)
        background = "#101827"
        eye = "#e8f4fa"
        iris = "#36d6c2"
        pupil = "#101827"
        highlight = "#ffffff"
        for y in range(48):
            row = []
            for x in range(48):
                nx = (x - 23.5) / 19.0
                ny = (y - 23.5) / 12.5
                edge = 0.72 * max(0.0, 1.0 - nx * nx) ** 0.5
                color = eye if abs(nx) <= 1 and abs(ny) <= edge else background
                iris_distance = ((x - 24) ** 2 + (y - 24) ** 2) ** 0.5
                if iris_distance <= 7:
                    color = iris
                if iris_distance <= 3.5:
                    color = pupil
                if (x - 21) ** 2 + (y - 21) ** 2 <= 2:
                    color = highlight
                row.append(color)
            image.put("{" + " ".join(row) + "}", to=(0, y))
        return image

    def network_worker(self) -> None:
        while not self.stopping.is_set():
            try:
                with connect(
                    self.uri,
                    open_timeout=3,
                    close_timeout=2,
                    proxy=None,
                ) as websocket:
                    initial = json.loads(websocket.recv(timeout=5))
                    self.events.put((
                        "connected",
                        initial.get("message", "Connected to EyeSync."),
                    ))
                    while not self.stopping.is_set():
                        try:
                            phrase = self.commands.get(timeout=0.1)
                        except queue.Empty:
                            phrase = ""
                        if phrase:
                            websocket.send(json.dumps({
                                "cmd": "wispr_command",
                                "text": phrase,
                            }))
                        try:
                            raw = websocket.recv(timeout=0.1)
                        except TimeoutError:
                            continue
                        message = json.loads(raw)
                        if message.get("status") == "wispr_command":
                            self.events.put((
                                "result",
                                message.get("message", "Command processed."),
                            ))
                        elif message.get("status") == "tab_gesture":
                            self.events.put((
                                "gesture",
                                message.get("message", "Tab gesture status updated."),
                            ))
                        elif message.get("status") in {
                            "camera_error", "needs_calibration", "model_running",
                        }:
                            self.events.put((
                                "gesture",
                                message.get("message", "EyeSync status updated."),
                            ))
            except (OSError, ConnectionClosed, TimeoutError, ValueError) as exc:
                self.events.put(("disconnected", f"Waiting for EyeSync: {exc}"))
                self.stopping.wait(2)

    def poll_events(self) -> None:
        while True:
            try:
                kind, message = self.events.get_nowait()
            except queue.Empty:
                break
            if kind == "connected":
                self.connected = True
                self.gesture_status.set(message)
                self.status_text.set("Connected to EyeSync.")
            elif kind == "disconnected":
                self.connected = False
                self.gesture_status.set(message)
                self.status_text.set(message)
            elif kind == "gesture":
                self.gesture_status.set(message)
            elif kind == "result":
                self.status_text.set(message)
        if not self.stopping.is_set():
            self.root.after(150, self.poll_events)

    def close(self) -> None:
        self.stopping.set()
        self.root.destroy()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ws-host", default="127.0.0.1")
    parser.add_argument("--ws-port", type=int, default=8765)
    args = parser.parse_args()
    root = tk.Tk()
    WisprCommandPanel(root, f"ws://{args.ws_host}:{args.ws_port}")
    root.mainloop()


if __name__ == "__main__":
    main()
