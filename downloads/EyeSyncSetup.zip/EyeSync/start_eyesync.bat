@echo off
cd /d "%~dp0"
python setup_and_start.py
pause
