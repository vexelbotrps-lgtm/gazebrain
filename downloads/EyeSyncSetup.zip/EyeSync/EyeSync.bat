@echo off
cd /d "%~dp0"
echo EyeSync will set up Python 3.12, Handy voice recognition, and its own dependencies.
echo Windows requires you to run this setup file once after extracting the download.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_eyesync.ps1" -ProjectRoot "%~dp0."
if errorlevel 1 pause
