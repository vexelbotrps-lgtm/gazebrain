"""Small Windows launcher for EyeSync calibration and tracking."""
from __future__ import annotations

import queue
import socket
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk

ROOT = Path(__file__).resolve().parent
CALIBRATION_STEPS = (
    ("Gaze calibration", "calibrate.py", ("--auto-start",), "gaze"),
    ("Smile sample calibration", "calibrate_left_click.py", ("--samples-only",), "smile"),
    ("Wink sample calibration", "calibrate_right_click.py", ("--samples-only",), "wink"),
    ("Both-eyes-closed Tab calibration", "calibrate_tab.py", (), "tab"),
)


def run_calibration_sequence(run_step, validate_step, report) -> bool:
    """Run and validate every calibration in order, stopping on the first failure."""
    for label, script, arguments, validation_key in CALIBRATION_STEPS:
        report(f"Starting {label}...")
        result = run_step(script, arguments)
        output = (result.stdout or "") + (result.stderr or "")
        if output.strip():
            report(output.strip())
        if result.returncode != 0:
            report(f"{label} failed (exit code {result.returncode}); later steps were not started.")
            return False
        if not validate_step(validation_key):
            report(f"{label} did not produce valid calibration data; later steps were not started.")
            return False
        report(f"{label} completed successfully.")
    report(f"All {len(CALIBRATION_STEPS)} calibration steps completed successfully.")
    return True


def _validate_calibration(key: str) -> bool:
    if key == "gaze":
        import gaze_core

        try:
            gaze_core.load_model_bundle()
        except (FileNotFoundError, ValueError, OSError):
            return False
        return True
    if key == "smile":
        import calibrate_left_click

        return calibrate_left_click.has_saved_samples()
    if key == "wink":
        import calibrate_right_click

        return calibrate_right_click.has_saved_samples()
    if key == "tab":
        import gaze_core

        return gaze_core.load_tab_profile() is not None
    raise ValueError(f"Unknown calibration result: {key}")


def _available_tracker_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        try:
            probe.bind(("127.0.0.1", 8765))
            return 8765
        except OSError:
            probe.bind(("127.0.0.1", 0))
            return int(probe.getsockname()[1])


class EyeSyncApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.events: queue.Queue = queue.Queue()
        self.processes: list[subprocess.Popen] = []
        self.process_lock = threading.Lock()
        self.busy = False
        self.tracker_started = False

        root.title("EyeSync")
        root.geometry("570x430")
        root.minsize(480, 360)
        root.protocol("WM_DELETE_WINDOW", self.close)

        frame = ttk.Frame(root, padding=24)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="EyeSync", font=("Segoe UI", 22, "bold")).pack(anchor="w")
        ttk.Label(
            frame,
            text=(
                "Choose whether to calibrate first or start the local tracker now. "
                "Calibration is optional."
            ),
            wraplength=510,
        ).pack(anchor="w", pady=(5, 16))

        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(0, 14))
        self.calibrate_button = ttk.Button(
            buttons, text="Calibrate", command=self.calibrate
        )
        self.calibrate_button.pack(side="left", fill="x", expand=True, padx=(0, 6), ipady=8)
        self.start_button = ttk.Button(
            buttons, text="Start EyeSync", command=self.start_eyesync
        )
        self.start_button.pack(side="left", fill="x", expand=True, padx=(6, 0), ipady=8)

        ttk.Label(
            frame,
            text=(
                "Calibration order: gaze → smile samples → wink samples → "
                "both-eyes-closed Tab gesture. "
                "Each step must succeed before the next begins. Without valid "
                "gaze calibration, EyeSync still starts but cursor movement stays "
                "off. Gesture calibrations are optional for starting EyeSync."
            ),
            wraplength=510,
        ).pack(anchor="w", pady=(0, 10))
        self.status = ttk.Label(frame, text="Ready.", wraplength=510)
        self.status.pack(anchor="w", pady=(0, 7))
        self.log = tk.Text(frame, height=10, wrap="word", state="disabled")
        self.log.pack(fill="both", expand=True)

        self.root.after(100, self._drain_events)

    def _report(self, message: str) -> None:
        self.events.put(("log", message))

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        state = "disabled" if busy or self.tracker_started else "normal"
        self.calibrate_button.configure(state=state)
        self.start_button.configure(state=state)

    def calibrate(self) -> None:
        if self.busy or self.tracker_started:
            return
        self._set_busy(True)
        self.status.configure(text="Calibration in progress. Follow each on-screen prompt.")
        threading.Thread(target=self._calibrate_worker, daemon=True).start()

    def _calibrate_worker(self) -> None:
        def run_step(script: str, arguments: tuple[str, ...]) -> subprocess.CompletedProcess:
            return subprocess.run(
                [sys.executable, str(ROOT / script), *arguments],
                cwd=ROOT,
                capture_output=True,
                text=True,
                check=False,
            )

        try:
            success = run_calibration_sequence(run_step, _validate_calibration, self._report)
        except Exception as exc:
            self._report(f"Calibration stopped because of an error: {exc}")
            success = False
        self.events.put(("calibration_done", success))

    def start_eyesync(self) -> None:
        if self.busy or self.tracker_started:
            return
        self._set_busy(True)
        self.status.configure(text="Starting the tracker and local command panel...")
        threading.Thread(target=self._start_worker, daemon=True).start()

    def _start_worker(self) -> None:
        started: list[subprocess.Popen] = []
        try:
            port = _available_tracker_port()
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            commands = (
                (
                    "command panel",
                    [
                        sys.executable,
                        str(ROOT / "wispr_command_panel.py"),
                        "--ws-host", "127.0.0.1",
                        "--ws-port", str(port),
                    ],
                ),
                (
                    "tracker",
                    [
                        sys.executable,
                        str(ROOT / "live.py"),
                        "--standalone-mouse",
                        "--enable-click-gestures",
                        "--ws-host", "127.0.0.1",
                        "--ws-port", str(port),
                    ],
                ),
            )
            for name, command in commands:
                process = subprocess.Popen(
                    command,
                    cwd=ROOT,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    creationflags=creationflags,
                )
                started.append(process)
                with self.process_lock:
                    self.processes.append(process)
                self.events.put(("process_started", process, name))
        except OSError as exc:
            for process in started:
                self._stop_process(process)
            self.events.put(("start_failed", str(exc)))
            return
        self.events.put(("start_done",))
        for process, (name, _command) in zip(started, commands):
            threading.Thread(
                target=self._read_process_output,
                args=(process, name),
                daemon=True,
            ).start()

    def _read_process_output(self, process: subprocess.Popen, name: str) -> None:
        if process.stdout is not None:
            for line in process.stdout:
                self.events.put(("log", f"{name}: {line.rstrip()}"))
        code = process.wait()
        self.events.put(("process_exited", process, name, code))

    def _drain_events(self) -> None:
        while True:
            try:
                event = self.events.get_nowait()
            except queue.Empty:
                break
            kind = event[0]
            if kind == "log":
                self.log.configure(state="normal")
                self.log.insert("end", event[1] + "\n")
                self.log.see("end")
                self.log.configure(state="disabled")
            elif kind == "calibration_done":
                self._set_busy(False)
                self.status.configure(
                    text="Calibration complete." if event[1]
                    else "Calibration did not complete. Review the details below, then retry."
                )
            elif kind == "process_started":
                _, process, name = event
                self.status.configure(text=f"{name.capitalize()} started.")
            elif kind == "start_done":
                self.tracker_started = True
                self._set_busy(False)
                self.status.configure(
                    text=(
                        "EyeSync is running. If calibration data is missing, "
                        "cursor movement remains off until gaze calibration is "
                        "complete. Smile/wink samples are optional."
                    )
                )
            elif kind == "start_failed":
                self._set_busy(False)
                self.status.configure(text=f"Could not start EyeSync: {event[1]}")
            elif kind == "process_exited":
                _, process, name, code = event
                with self.process_lock:
                    if process in self.processes:
                        self.processes.remove(process)
                    remaining = list(self.processes)
                    self.processes.clear()
                for other in remaining:
                    self._stop_process(other)
                self.tracker_started = False
                self._set_busy(False)
                message = (
                    f"The {name} closed; EyeSync has stopped."
                    if code == 0 else
                    f"The {name} stopped with exit code {code}. See details below."
                )
                self.status.configure(text=message)
        self.root.after(100, self._drain_events)

    @staticmethod
    def _stop_process(process: subprocess.Popen) -> None:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()

    def close(self) -> None:
        with self.process_lock:
            processes = list(self.processes)
            self.processes.clear()
        for process in processes:
            self._stop_process(process)
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    EyeSyncApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
