param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot,
    [switch]$ValidateOnly
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Get-PythonLauncher {
    $launcher = Get-Command "py.exe" -ErrorAction SilentlyContinue
    if ($launcher) {
        return $launcher.Source
    }

    $launcherPath = Join-Path $env:LOCALAPPDATA "Programs\Python\Launcher\py.exe"
    if (Test-Path -LiteralPath $launcherPath) {
        return $launcherPath
    }
    return $null
}

function Test-Python312Installed {
    $launcher = Get-PythonLauncher
    if (-not $launcher) {
        return $false
    }
    & $launcher -3.12 --version *> $null
    return $LASTEXITCODE -eq 0
}

function Install-Python312 {
    $installerUrl = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe"
    $installerPath = Join-Path $env:TEMP "EyeSync-Python-3.12.10-amd64.exe"
    Write-Host "Downloading the official Python 3.12.10 (64-bit) installer..."
    Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath -UseBasicParsing

    $signature = Get-AuthenticodeSignature -FilePath $installerPath
    if ($signature.Status -ne "Valid" -or
        $signature.SignerCertificate.Subject -notlike "*Python Software Foundation*") {
        throw "The downloaded Python installer did not have a valid Python Software Foundation signature."
    }

    Write-Host "Installing Python 3.12.10 for the current Windows user..."
    $process = Start-Process -FilePath $installerPath -ArgumentList @(
        "/quiet",
        "InstallAllUsers=0",
        "PrependPath=1",
        "Include_launcher=1",
        "Include_pip=1",
        "Include_test=0",
        "Shortcuts=0"
    ) -Wait -PassThru
    Remove-Item -LiteralPath $installerPath -ErrorAction SilentlyContinue
    if ($process.ExitCode -notin @(0, 3010)) {
        throw "Python installation failed with exit code $($process.ExitCode)."
    }

    $launcherDirectory = Join-Path $env:LOCALAPPDATA "Programs\Python\Launcher"
    if (Test-Path -LiteralPath $launcherDirectory) {
        $env:PATH = "$launcherDirectory;$env:PATH"
    }
    if (-not (Test-Python312Installed)) {
        throw "Python 3.12 was installed, but the Python launcher could not find it."
    }
}

function Test-HandyInstalled {
    $uninstallLocations = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )
    $installedApps = Get-ItemProperty -Path $uninstallLocations -ErrorAction SilentlyContinue
    return [bool]($installedApps | Where-Object {
        $_.DisplayName -eq "Handy"
    } | Select-Object -First 1)
}

function Install-Handy {
    $headers = @{ "User-Agent" = "EyeSync-Setup" }
    $release = Invoke-RestMethod `
        -Uri "https://api.github.com/repos/cjpais/Handy/releases/latest" `
        -Headers $headers
    $asset = $release.assets | Where-Object {
        $_.name -match "_x64_en-US\.msi$"
    } | Select-Object -First 1
    if (-not $asset -or $asset.digest -notmatch "^sha256:[a-fA-F0-9]{64}$") {
        throw "Could not find a SHA-256-verifiable official Handy Windows installer."
    }
    $expectedDigest = $asset.digest.Substring(7)

    $installerPath = Join-Path $env:TEMP $asset.name
    Write-Host "Downloading Handy voice recognition ($($release.tag_name)) from its official GitHub release..."
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $installerPath -UseBasicParsing
    $actualDigest = (Get-FileHash -LiteralPath $installerPath -Algorithm SHA256).Hash
    if ($actualDigest -ne $expectedDigest) {
        Remove-Item -LiteralPath $installerPath -ErrorAction SilentlyContinue
        throw "Handy installer checksum verification failed."
    }

    Write-Host "Installing Handy for the current Windows user..."
    $logPath = Join-Path $env:TEMP "EyeSync-Handy-Install.log"
    $process = Start-Process -FilePath "msiexec.exe" -ArgumentList @(
        "/i",
        "`"$installerPath`"",
        "/qn",
        "/norestart",
        "/l*v",
        "`"$logPath`""
    ) -Wait -PassThru
    Remove-Item -LiteralPath $installerPath -ErrorAction SilentlyContinue
    if ($process.ExitCode -notin @(0, 3010)) {
        throw "Handy installation failed with exit code $($process.ExitCode). Installer log: $logPath"
    }
    if (-not (Test-HandyInstalled)) {
        throw "The Handy installer completed, but Windows does not report Handy as installed."
    }
}

function New-EyeSyncDesktopShortcut([string]$Root) {
    $launcher = Get-PythonLauncher
    if (-not $launcher) {
        throw "The Python launcher is unavailable, so EyeSync cannot be added to the desktop."
    }

    $venvPythonw = Join-Path $Root ".venv\Scripts\pythonw.exe"
    if (-not (Test-Path -LiteralPath $venvPythonw)) {
        throw "The EyeSync virtual environment is missing pythonw.exe."
    }
    $appScript = Join-Path $Root "eyesync_app.py"
    $desktop = [Environment]::GetFolderPath("Desktop")
    $shortcutPath = Join-Path $desktop "EyeSync.lnk"
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $venvPythonw
    $shortcut.Arguments = "`"$appScript`""
    $shortcut.WorkingDirectory = $Root
    $shortcut.Description = "Start EyeSync accessibility controls"
    $shortcut.Save()
    return $venvPythonw
}

try {
    if (-not [Environment]::Is64BitOperatingSystem) {
        throw "EyeSync setup requires 64-bit Windows."
    }
    $resolvedRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
    if (-not (Test-Path -LiteralPath (Join-Path $resolvedRoot "quick_setup.py"))) {
        throw "quick_setup.py was not found. Extract the full EyeSync download before running setup."
    }
    if ($ValidateOnly) {
        Write-Host "EyeSync project directory is valid: $resolvedRoot"
        Write-Host "Python 3.12 installed: $(Test-Python312Installed)"
        Write-Host "Handy installed: $(Test-HandyInstalled)"
        exit 0
    }

    $installRoot = Join-Path $env:LOCALAPPDATA "Programs\EyeSync"
    if (-not [string]::Equals(
        $resolvedRoot.TrimEnd("\"),
        $installRoot.TrimEnd("\"),
        [System.StringComparison]::OrdinalIgnoreCase
    )) {
        New-Item -ItemType Directory -Path $installRoot -Force | Out-Null
        Write-Host "Copying EyeSync into your local applications folder..."
        & robocopy.exe $resolvedRoot $installRoot /E /R:2 /W:1 `
            /XD ".git" ".venv" ".sentry-native" "__pycache__" `
            /XF "*.pyc" "gaze_data.npz" "gaze_model.joblib" "smile_samples.npz" `
            "wink_samples.npz" "mouth_open_profile.json" "tab_profile.json" `
            "blink_profile.json" "click_profile.joblib" "click_samples*.npz" `
            "puff_samples.npz" "puff_model.joblib" "live_run.log"
        $copyExitCode = $LASTEXITCODE
        if ($copyExitCode -gt 7) {
            throw "Could not copy EyeSync into its local applications folder (robocopy exit code $copyExitCode)."
        }
        $resolvedRoot = $installRoot
    }

    if (-not (Test-Python312Installed)) {
        Install-Python312
    } else {
        Write-Host "Python 3.12 is already installed."
    }

    if (-not (Test-HandyInstalled)) {
        Install-Handy
    } else {
        Write-Host "Handy is already installed."
    }

    $pythonLauncher = Get-PythonLauncher
    if (-not $pythonLauncher) {
        throw "The Python launcher is unavailable."
    }
    Write-Host "Installing EyeSync dependencies. This may take a few minutes..."
    & $pythonLauncher -3.12 (Join-Path $resolvedRoot "quick_setup.py") --prepare-only
    if ($LASTEXITCODE -ne 0) {
        throw "EyeSync dependency setup failed with exit code $LASTEXITCODE."
    }

    $appInterpreter = New-EyeSyncDesktopShortcut -Root $resolvedRoot
    $appScript = Join-Path $resolvedRoot "eyesync_app.py"
    Write-Host "Created the EyeSync desktop shortcut. Starting EyeSync..."
    Start-Process -FilePath $appInterpreter `
        -ArgumentList "`"$appScript`"" `
        -WorkingDirectory $resolvedRoot
} catch {
    Write-Host ""
    Write-Host "EyeSync setup failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
