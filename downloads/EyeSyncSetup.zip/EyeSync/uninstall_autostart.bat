@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\EyeSync.lnk" 2>nul
taskkill /F /IM pythonw.exe >nul 2>&1
echo EyeSync auto-start removed.
pause
