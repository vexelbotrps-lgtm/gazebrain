# Local client protocol

## WebSocket gaze stream

| Endpoint | Use | Coordinates |
|---|---|---|
| `ws://localhost:8765` | Default local desktop endpoint | Pixels of the calibrated screen |

When `setup_and_start.py` finds an incompatible service already using port 8765,
it leaves that service alone, chooses an available local port, and prints the
actual `ws://127.0.0.1:<port>` endpoint to use for this tracker.

About 30 messages per second:

```json
{"x": 683.0, "y": 384.0, "blink": false, "click": null, "keyboard_opened": false}
```

`click` is `null`, `"left"` or `"right"` (one message per click).
In the live tracker, a closed-mouth smile held for 1.2 seconds produces
`"left"`; opening the mouth continuously for 1 second produces `"right"`.
The Wispr Flow command panel accepts only the explicitly supported keyboard
and OSK positioning phrases. Open/close/resize commands and OSK positioning are
sent over the local WebSocket connection. A `keyboard_opened` value of `true`
is broadcast once after the OSK is launched. OSK repositioning starts only
when mouse control is enabled and the cursor is already on the OSK title bar.
“Done adjusting the position of the on-screen keyboard” stops keyboard
repositioning. The command panel uses its normal window controls for its own
size and position.
The command panel never executes arbitrary dictated text. Wispr Flow processes
dictated audio to provide its service; see the README privacy note.
The left/right facial click event protocol and gesture thresholds are unchanged.
`calibrations_ready` reports whether gaze calibration is valid; pointer control
also requires the live preview. Left-click compares face-landmark mouth width
to a relaxed-mouth baseline learned at startup, and requires at least a 15%
increase for the full hold. Mouth opening cancels it, and relaxing the mouth
rearms it. It does not depend on webcam mouth-image detail. The existing click
thresholds, holds, and rearming are unchanged. If the
mouth-open profile is missing, right-click
uses built-in mouth-opening thresholds. The optional right-click profile is
stored in `mouth_open_profile.json`.

Separately, closing both eyes for 1 second sends one local Tab key press
followed by its release. Reopen both eyes for at least 0.25 seconds to rearm;
closing them again sends another Tab tap. The detector learns per-eye open-EAR
baselines at startup and requires each normalized ratio to fall to 0.84 or
below before timing a closure. This reduces false activations from ordinary
eye-ratio variation while remaining more responsive to deliberate squints and
relative to individual eye shape. The
command panel and preview display live eye ratios and hold progress. The
detector tolerates up to 200 ms of ambiguous eye classification and cancels an
in-progress hold
after camera-frame loss. Closing only one eye does not trigger Tab. A
confirmation beep plays as Windows accepts each Tab press. The local cursor is
held at its current position during a recognized smile, mouth-open, or Tab
gesture; gaze filtering resumes from that position after the gesture ends. The
key event is local and is not included in gaze-stream messages. Configure your
speech tool (for example, Handy AI) to use Tab as its push-to-talk shortcut.
The exact supported command phrases remain limited to the local command panel.

With the tracker stopped, run `python setup_and_start.py` to collect required
numeric gesture samples before tracking. The sample archives are retained and
new sessions append to them; webcam images and video are not saved. Personalized
mouth-open threshold calibration remains optional and valid profiles are
preserved. The retained smile and eye sample archives are not used by the live
click detectors.
Smile samples include neutral, closed-lip smile, relaxed teeth-showing and
teeth-showing smile expressions in four poses. Eye samples include open-eye
and left/right wink measurements in four poses for local data collection.
Each gesture prompt
has a five-second ready period before recording starts. Webcam frames are processed
in memory; only classifier parameters, gesture thresholds, and local numeric
samples are saved. When
personalized mouth-open thresholds are unavailable, the built-in thresholds are
used. Brief threshold ambiguity (up to 150 ms) does not interrupt the right-click
hold; closing the mouth longer resets it.
Only origins on the allow-list may connect (`--allow-origin <url>` adds one).

Status messages are sent to connected local clients:

```json
{"status": "calibration_state | needs_calibration | needs_consent | calibrating | calibration_done | calibration_failed | preview_not_ready | busy", "message": "...", "calibrations_ready": false, "mouth_open_profile_calibrated": false, "right_click_fallback": true, "right_click_ready": true, "preview_ready": false}
```

`calibrations_ready` means gaze calibration is valid.
`right_click_ready` reports whether click gestures are enabled and gaze is ready;
`right_click_fallback` means right-click is using built-in mouth-opening
thresholds because the optional mouth-open profile is missing.

After obtaining the user's consent, a local client sends
`{"cmd":"calibration_consent","accepted":true}` to complete required gaze
calibration and missing numeric gesture-sample collection. The `"calibrate"`
command, or `"calibrate": true` on the consent message, runs required missing
steps only. Left-click needs no eye calibration. Gaze calibration begins
without requiring a SPACE keypress. Existing profiles are retained unless and
until their replacement calibration succeeds.

## Local mouse control

The tracker controls the Windows mouse directly. No XIAO, ESP32, USB HID firmware,
or serial connection is required. Mouse control starts disabled in every mode.

After calibration the tracker streams a gaze preview; the user should check it
and explicitly enable control from the local client. Control must remain
unavailable until calibration and preview are ready. The client can turn
control off or back on with the same command.

| Direction | Message | Meaning |
|---|---|---|
| client -> tracker | `{"cmd":"mouse","enabled":false}` | turn local mouse control off (`true` = on) |
| tracker -> client | `{"status":"mouse","enabled":bool,"message":"..."}` | local control state, sent on connect and change |
| client -> tracker | `{"cmd":"wispr_command","text":"open the on-screen keyboard"}` | run an exact allow-listed keyboard command |
| tracker -> client | `{"status":"wispr_command","ok":bool,"message":"..."}` | command result |

Safety: local control switches off automatically when the last client disconnects, pauses
when no face has been seen for 2 s, and `Ctrl+Alt+E` turns it off from anywhere (Windows).
