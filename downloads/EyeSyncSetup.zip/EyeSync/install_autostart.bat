@echo off
rem Makes EyeSync start silently at every Windows login (no admin needed) by putting a
rem shortcut in your Startup folder. It idles (camera OFF) until a local client connects.
cd /d "%~dp0"
set "PYW="
for /f "delims=" %%P in ('python -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))" 2^>nul') do set "PYW=%%P"
if not defined PYW (echo Python not found. Install Python and tick "Add to PATH".& pause & exit /b 1)
if not exist "%PYW%" (echo pythonw.exe not found at %PYW%& pause & exit /b 1)
powershell -NoProfile -Command "$l=Join-Path ([Environment]::GetFolderPath('Startup')) 'EyeSync.lnk'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($l); $s.TargetPath=$env:PYW; $s.Arguments='\"%~dp0live.py\" --client-only --enable-click-gestures'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Save()"
if errorlevel 1 (echo Failed to create the startup shortcut.& pause & exit /b 1)
start "" "%PYW%" "%~dp0live.py" --client-only --enable-click-gestures
echo Done. EyeSync is running in the background and will start at every login.
echo The tracker will wait for a local client connection.
pause
