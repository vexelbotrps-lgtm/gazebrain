"""Real-time face-gaze inference, local mouse control, and local client streaming."""
from __future__ import annotations

import argparse
import asyncio
import ctypes
import json
import logging
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from ctypes import wintypes

import cv2
from websockets.asyncio.server import broadcast, serve
from websockets.exceptions import ConnectionClosed

import gaze_core as gc
import voice_commands as vc

log = logging.getLogger("gaze")

WS_HOST, WS_PORT = "localhost", 8765
BROADCAST_HZ = 30
MOUSE_HZ = 30
MAX_FAILED_READS = 30            # consecutive failed camera reads before re-opening
# Permit local desktop/webview clients and non-browser clients by default.
DEFAULT_ALLOWED_ORIGINS = [
    None,                                    # native clients (no Origin header)
    "http://localhost", "http://127.0.0.1",
]


# ---------------------------------- shared state ---------------------------------- #
@dataclass
class SharedState:
    """Written by the vision loop, read by the mouse and WebSocket loops.
    All access happens on the event-loop thread, so no locking is needed."""
    x: float = 0.0
    y: float = 0.0
    has_position: bool = False
    ws_blink_pending: bool = False      # consumed (cleared) by the next broadcast tick
    mouse_click_pending: Optional[str] = None  # consumed by the next local-mouse tick
    ws_click: Optional[str] = None      # which click the next broadcast reports
    keyboard_adjusting: bool = False
    keyboard_opened_pending: bool = False
    keyboard_open: bool = False
    tab_key_held: bool = False
    tab_key_retry_at: float = 0.0
    cursor_frozen: bool = False
    client_count: int = 0
    screen_w: float = 1366.0
    screen_h: float = 768.0
    calibrate_requested: bool = False   # set by a local client, consumed by vision_loop
    calibrating: bool = False           # real mouse is frozen while True
    calibration_ready: bool = False     # required gaze calibration is valid
    calibration_consent: bool = False
    calibration_process: Optional[asyncio.subprocess.Process] = None
    mouse_enabled: bool = False         # local cursor obeys gaze only while True
    mouse_notify: bool = False          # broadcast_loop tells clients the new mouse state
    face_seen_at: float = 0.0           # monotonic time of the last frame with a face
    gaze_ready: bool = False            # gaze profile is sufficient for pointer movement


def tap_tab_key(state: SharedState) -> bool:
    """Send one Tab press/release pair, tracking a failed release for retry."""
    if state.tab_key_held:
        log.warning("Skipping Tab tap while a prior key release is pending.")
        return False
    try:
        vc.set_tab_key_down(True)
    except OSError as exc:
        log.error("Could not press Tab: %s", exc)
        return False

    state.tab_key_held = True
    try:
        vc.play_tab_confirmation()
    except (ImportError, OSError, RuntimeError) as exc:
        log.error("Tab was pressed, but its confirmation beep failed: %s", exc)
    try:
        vc.set_tab_key_down(False)
    except OSError as exc:
        log.error("Could not release Tab after tap: %s", exc)
        state.tab_key_retry_at = time.monotonic()
        return False

    state.tab_key_held = False
    state.tab_key_retry_at = 0.0
    log.info("Tab key tapped by one-second bilateral eye closure.")
    return True


class Ticker:
    """Fixed-rate pacing that does not drift and does not burst after a stall."""

    def __init__(self, hz: float) -> None:
        self.period = 1.0 / hz
        self._next = time.monotonic()

    async def wait(self) -> None:
        self._next += self.period
        now = time.monotonic()
        if self._next < now:
            self._next = now
        await asyncio.sleep(self._next - now)


# ------------------------------------ vision ------------------------------------ #
@dataclass
class StepResult:
    xy: Optional[tuple[float, float]] = None
    click: Optional[str] = None   # None, "left" or "right"
    tab_key_tap: bool = False
    cursor_frozen: bool = False
    face: bool = False
    quit: bool = False


class VisionPipeline:
    """Camera + FaceMesh + MLP + smoothing + blink. step() is BLOCKING and is always
    called from one single worker thread (also keeps cv2.imshow on one thread)."""

    def __init__(self, bundle: dict, args: argparse.Namespace) -> None:
        self.bundle = bundle
        self.args = args
        cap = gc.open_camera(args.camera)
        camera_size = gc.camera_frame_size(cap)
        if tuple(bundle["camera_size"]) != camera_size:
            cap.release()
            raise ValueError(
                f"Gaze model was calibrated at {bundle['camera_size'][0]}x"
                f"{bundle['camera_size'][1]}, but the camera is now {camera_size[0]}x"
                f"{camera_size[1]}; run `python calibrate.py` again."
            )
        self.extractor = gc.FaceFeatureExtractor()
        self.cap = gc.LatestFrameCamera(cap)
        self.feat_ema = gc.VectorEma(args.alpha)
        self.smoother = gc.OneEuroFilter2D(args.min_cutoff, args.beta)
        self.smile_click = gc.LandmarkSmileClickDetector()
        tab_profile = gc.load_tab_profile()
        if tab_profile is None and gc.TAB_PROFILE_PATH.exists():
            log.warning(
                "The saved Tab gesture profile is invalid; using built-in "
                "eye-closure thresholds."
            )
        elif tab_profile is not None:
            log.info("Using personalized both-eyes-closed Tab thresholds.")
        self.eye_closure = gc.BilateralEyeClosureDetector(tab_profile)
        mouth_profile = gc.load_mouth_open_profile()
        if mouth_profile is None:
            log.warning(
                "No valid mouth-open profile; using built-in thresholds for "
                "one-second mouth-open right-click."
            )
        self.right_click_enabled = args.enable_click_gestures
        self.enable_click_gestures = args.enable_click_gestures
        self.mouth_click = gc.MouthOpenClickDetector(mouth_profile)
        if mouth_profile:
            log.info("Using personalized mouth-open thresholds (mouth_open_profile.json).")
        if self.enable_click_gestures:
            log.warning("Facial click gestures are enabled; recalibrate if they trigger unintentionally.")
        else:
            log.info("Facial click gestures are disabled; cursor movement remains active.")
        self.last_xy: Optional[tuple[float, float]] = None
        self.cursor_gesture_active = False
        self.failed_reads = 0
        self.smile_debug: Optional[tuple[float, float]] = None
        self.mouth_debug: Optional[tuple[float, float, float, float]] = None
        self.eye_closure_debug: Optional[tuple[float, float, float]] = None

    def _reopen_camera(self) -> None:
        log.warning("Camera stopped delivering frames; trying to re-open it...")
        self.cap.release()
        for attempt in range(1, 4):
            time.sleep(1.0)
            try:
                self.cap = gc.LatestFrameCamera(gc.open_camera(self.args.camera))
                self.failed_reads = 0
                log.info("Camera re-opened.")
                return
            except gc.CameraError:
                log.warning("Re-open attempt %d/3 failed.", attempt)
        raise gc.CameraError("Camera disconnected and could not be re-opened.")

    def step(self) -> StepResult:
        ok, frame = self.cap.read()
        if not ok or frame is None:
            self.eye_closure.cancel_hold()
            self.failed_reads += 1
            if self.failed_reads >= MAX_FAILED_READS:
                self._reopen_camera()          # raises CameraError if it cannot recover
            time.sleep(0.01)
            return StepResult(
                xy=self.last_xy,
                cursor_frozen=self.cursor_gesture_active,
            )
        self.failed_reads = 0

        res = self.extractor.process(frame)
        click: Optional[str] = None
        tab_key_tap = False
        was_gesture_active = self.cursor_gesture_active
        resume_after_gesture = False
        self.smile_debug = None
        self.mouth_debug = None
        self.eye_closure_debug = None
        if res is None:
            self.smile_click.reset()
            self.mouth_click.reset()
            self.eye_closure.cancel_hold()
        else:
            mouth_open = float(res.smile_features[1])
            tab_key_tap = self.eye_closure.update(
                res.ear_left, res.ear_right,
            )
            self.eye_closure_debug = (
                self.eye_closure.last_left,
                self.eye_closure.last_right,
                self.eye_closure.hold_progress,
            )
            if self.enable_click_gestures:
                if self.right_click_enabled:
                    right_click = self.mouth_click.update(mouth_open)
                    self.mouth_debug = (
                        mouth_open, self.mouth_click.open_threshold,
                        self.mouth_click.release_threshold,
                        self.mouth_click.hold_progress * self.mouth_click.HOLD_S,
                    )
                else:
                    self.mouth_click.reset()
                    right_click = False
                left_click = self.smile_click.update(
                    float(res.smile_features[0]),
                    float(res.smile_features[1]),
                    self.mouth_click.release_threshold,
                )
                self.smile_debug = (
                    self.smile_click.last_ratio,
                    self.smile_click.hold_progress,
                )
                if self.mouth_click.active:
                    self.smile_click.reset()
                    left_click = False
                click = "right" if right_click else "left" if left_click else None
            else:
                self.smile_click.reset()
                self.mouth_click.reset()
            gesture_active = (
                self.eye_closure.active
                or (self.enable_click_gestures and (
                    self.smile_click.active or self.mouth_click.active
                ))
            )
            if gesture_active:
                self.cursor_gesture_active = True
            elif was_gesture_active:
                self.cursor_gesture_active = False
                resume_after_gesture = True
                if self.last_xy is not None:
                    self.feat_ema = gc.VectorEma(self.args.alpha)
                    self.feat_ema.update(res.features)
                    self.smoother = gc.OneEuroFilter2D(
                        self.args.min_cutoff, self.args.beta
                    )
                    self.smoother.update(
                        self.last_xy[0], self.last_xy[1], time.monotonic()
                    )
            else:
                self.cursor_gesture_active = False

            if not self.cursor_gesture_active and not resume_after_gesture:
                feats = self.feat_ema.update(res.features)
                raw = gc.predict_xy(self.bundle, feats)
                self.last_xy = self.smoother.update(
                    raw[0], raw[1], time.monotonic()
                )
        if res is None:
            self.cursor_gesture_active = self.eye_closure.active
            if (was_gesture_active and not self.cursor_gesture_active
                    and self.last_xy is not None):
                self.feat_ema = gc.VectorEma(self.args.alpha)
                self.smoother = gc.OneEuroFilter2D(
                    self.args.min_cutoff, self.args.beta
                )
                self.smoother.update(
                    self.last_xy[0], self.last_xy[1], time.monotonic()
                )

        quit_requested = self._preview(frame, res) if self.args.preview else False
        return StepResult(
            xy=self.last_xy, click=click,
            tab_key_tap=tab_key_tap,
            cursor_frozen=self.cursor_gesture_active,
            quit=quit_requested, face=res is not None,
        )

    def _preview(self, frame, res) -> bool:
        h, w = frame.shape[:2]
        if res is not None:
            x0, y0, x1, y1 = res.features
            cv2.rectangle(frame, (int(x0 * w), int(y0 * h)), (int(x1 * w), int(y1 * h)),
                          (0, 255, 0), 2)
            cv2.putText(frame, f"EAR L/R {res.ear_left:.2f}/{res.ear_right:.2f}", (10, 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            cv2.putText(frame, f"Smile {res.smile:.2f}  Mouth {res.mouth:.2f}", (10, 52),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 255), 2)
            if self.eye_closure_debug is not None:
                tab_text = (
                    "Tab: learning open-eye baseline"
                    if not self.eye_closure.ready else
                    f"Tab eye ratios L/R {self.eye_closure_debug[0]:.2f}/"
                    f"{self.eye_closure_debug[1]:.2f} "
                    f"hold {self.eye_closure_debug[2] * self.eye_closure.HOLD_S:.1f}/"
                    f"{self.eye_closure.HOLD_S:.1f}s"
                )
                cv2.putText(
                    frame,
                    tab_text, (10, 130),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 2,
                )
            if self.mouth_debug is not None:
                mouth_open, open_threshold, release_threshold, hold_s = self.mouth_debug
                cv2.putText(
                    frame,
                    f"Mouth-open {mouth_open:.2f} "
                    f"(start {open_threshold:.2f}, release {release_threshold:.2f}) "
                    f"hold {hold_s:.1f}/{self.mouth_click.HOLD_S:.1f}s",
                    (10, 78), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (0, 255, 255), 2,
                )
            if self.smile_debug is not None:
                smile_text = (
                    f"Smile {self.smile_debug[0]:.2f}x neutral  "
                    f"hold {self.smile_debug[1] * self.smile_click.HOLD_S:.1f}/"
                    f"{self.smile_click.HOLD_S:.1f}s"
                    if self.smile_click.ready else
                    "Relax your mouth briefly to set the smile baseline"
                )
                cv2.putText(
                    frame,
                    smile_text, (10, 104),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.52, (0, 255, 255), 2,
                )
        cv2.imshow("gaze preview (ESC to quit)", frame)
        return (cv2.waitKey(1) & 0xFF) == 27

    def release_camera(self) -> None:
        self.cap.release()

    def reload_model(self, bundle: dict) -> None:
        self.bundle = bundle
        self.feat_ema = gc.VectorEma(self.args.alpha)
        self.smoother = gc.OneEuroFilter2D(self.args.min_cutoff, self.args.beta)
        self.smile_click.reset()
        self.mouth_click.reset()
        self.eye_closure.cancel_hold()

    def close(self) -> None:
        self.cap.release()
        self.extractor.close()
        if self.args.preview:
            cv2.destroyAllWindows()


async def run_calibration(pipeline: Optional[VisionPipeline], executor: ThreadPoolExecutor,
                          state: SharedState, clients: set,
                          args: argparse.Namespace) -> bool:
    """Calibrate only profiles that are currently missing or invalid."""
    def status(kind: str, msg: str) -> None:
        log.info("Calibration: %s", msg)
        broadcast(clients, json.dumps({"status": kind, "message": msg,
                                       "saved_to": str(gc.MODEL_PATH.parent),
                                       "calibrations_ready": state.calibration_ready,
                                       "preview_ready": state.has_position}))

    loop = asyncio.get_running_loop()
    state.calibrating = True
    state.calibration_ready = False
    state.has_position = False
    set_mouse(state, False, "calibration started")
    completed = False
    try:
        if pipeline is not None:
            await loop.run_in_executor(executor, pipeline.release_camera)
        missing = missing_calibrations(args.model)
        missing_samples = missing_sample_collections()
        calibrations = {
            "gaze": ("Gaze calibration: look at each screen dot.",
                    [sys.executable, str(Path(__file__).with_name("calibrate.py")),
                     "--camera", str(args.camera), "--ear-threshold", str(args.ear_threshold),
                     "--output", str(args.model), "--auto-start"]),
            "smile samples": (
                "Sample collection: follow the smile-expression prompts.",
                [sys.executable, str(Path(__file__).with_name(
                    "calibrate_left_click.py")), "--camera", str(args.camera),
                 "--samples-only"]),
            "wink samples": (
                "Sample collection: follow the wink prompts.",
                [sys.executable, str(Path(__file__).with_name(
                    "calibrate_right_click.py")), "--camera", str(args.camera),
                 "--samples-only"]),
            "Tab gesture": (
                "Tab gesture calibration: follow the both-eyes-open and "
                "both-eyes-closed prompts.",
                [sys.executable, str(Path(__file__).with_name("calibrate_tab.py")),
                 "--camera", str(args.camera)],
            ),
        }
        required_steps = ["gaze", "smile samples", "wink samples", "Tab gesture"]
        tab_profile_missing = gc.load_tab_profile() is None
        selected = [
            name for name in required_steps
            if (name in missing or name in missing_samples
                or (name == "Tab gesture" and tab_profile_missing))
        ]
        for name in selected:
            if name in {"smile samples", "wink samples"}:
                if name not in missing_sample_collections():
                    continue
            if name == "Tab gesture" and gc.load_tab_profile() is not None:
                continue
            message, cmd = calibrations[name]
            if not state.calibration_consent:
                status("calibration_failed",
                       "Calibration consent was withdrawn. Mouse control remains off.")
                return False
            status("calibrating", message)
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT
            )
            state.calibration_process = proc
            try:
                output, _ = await asyncio.wait_for(proc.communicate(), timeout=1200)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                if not state.calibration_consent:
                    status("calibration_failed",
                           "Calibration consent was withdrawn. Mouse control remains off.")
                    return False
                status("calibration_failed", "Calibration timed out. Mouse control remains off.")
                return False
            finally:
                state.calibration_process = None
            if not state.calibration_consent:
                status("calibration_failed",
                       "Calibration consent was withdrawn. Mouse control remains off.")
                return False
            if proc.returncode != 0:
                detail = output.decode(errors="replace").strip().splitlines()
                reason = detail[-1] if detail else "The calibration was cancelled or failed."
                status("calibration_failed",
                       f"{reason} Mouse control remains off; give consent and retry.")
                return False

        state.calibration_ready = calibration_assets_ready(args.model)
        state.gaze_ready = gaze_asset_ready(args.model)
        sample_missing = missing_sample_collections()
        if sample_missing:
            log.info(
                "Optional gesture sample collections are unavailable: %s",
                ", ".join(sample_missing),
            )
        required_missing = [
            item for item in missing_calibrations(args.model)
            if item == "gaze"
        ]
        if "Tab gesture" in selected and gc.load_tab_profile() is None:
            status(
                "calibration_failed",
                "The Tab gesture calibration did not produce a valid profile.",
            )
            return False
        if required_missing:
            status("calibration_failed",
                   "Required calibration profiles could not be validated: "
                   + ", ".join(required_missing) + ". Mouse control remains off.")
            return False
        if not selected:
            status(
                "calibration_done",
                "Required gaze calibration is ready; "
                "optional personalized gesture profiles were left unchanged.",
            )
            completed = True
            return True
        mouth_profile_fallback = gc.load_mouth_open_profile() is None
        status(
            "calibration_done",
            "Gaze and available gesture controls are ready."
            + (" Built-in mouth-open thresholds are active."
               if mouth_profile_fallback else ""),
        )
        completed = True
        return True
    except OSError as exc:
        log.error("Could not start calibration process: %s", exc)
        status("calibration_failed", f"Could not start a calibration step: {exc}")
        return False
    finally:
        state.calibrating = False
        state.calibration_ready = calibration_assets_ready(args.model)
        state.gaze_ready = gaze_asset_ready(args.model)
        if state.gaze_ready and not completed:
            status("calibration_done",
                   "Gaze calibration is ready.")


def missing_calibrations(model_path: str) -> list[str]:
    missing = []
    try:
        gc.load_model_bundle(Path(model_path))
    except (FileNotFoundError, ValueError):
        missing.append("gaze")
    return missing


def missing_sample_collections() -> list[str]:
    from calibrate_left_click import has_saved_samples as has_smile_samples
    from calibrate_right_click import has_saved_samples as has_wink_samples

    missing = []
    if not has_smile_samples():
        missing.append("smile samples")
    if not has_wink_samples():
        missing.append("wink samples")
    return missing


def calibration_assets_ready(model_path: str) -> bool:
    return not missing_calibrations(model_path)


def gaze_asset_ready(model_path: str) -> bool:
    try:
        gc.load_model_bundle(Path(model_path))
    except (FileNotFoundError, ValueError):
        return False
    return True


def calibration_needed_message(model_path: str) -> str:
    missing = missing_calibrations(model_path)
    required_missing = [name for name in missing if name == "gaze"]
    if required_missing:
        return (
            "Gaze calibration is missing or invalid. EyeSync can start, but cursor "
            "control is unavailable until gaze calibration is completed."
        )
    return (
        "Gaze calibration is ready. Optional smile/wink sample collections are "
        "not needed for the live gesture controls."
    )


def gesture_calibration_message() -> str:
    messages = []
    messages.append(
        "Left-click is ready: hold a smile for 1.2 seconds."
    )
    if gc.load_mouth_open_profile() is None:
        messages.append("Mouth-open right-click is ready using built-in thresholds.")
    else:
        messages.append("Mouth-open right-click is ready using personalized thresholds.")
    return " ".join(messages)


async def vision_loop(executor: ThreadPoolExecutor, state: SharedState, stop: asyncio.Event,
                      clients: set, args: argparse.Namespace) -> None:
    """Owns the camera and serves gaze data to connected local clients."""
    loop = asyncio.get_running_loop()
    pipeline: Optional[VisionPipeline] = None
    last_notice = 0.0
    eye_baseline_notified = False
    last_eye_status_at = 0.0

    def release_tab_key(reason: str) -> None:
        if (not state.tab_key_held
                or time.monotonic() < state.tab_key_retry_at):
            return
        try:
            vc.set_tab_key_down(False)
        except OSError as exc:
            log.error("Could not release Tab (%s): %s", reason, exc)
            state.tab_key_retry_at = time.monotonic() + 1.0
        else:
            state.tab_key_held = False
            state.tab_key_retry_at = 0.0
            log.info("Tab key released (%s).", reason)

    async def drop_pipeline() -> None:
        nonlocal pipeline, eye_baseline_notified
        if pipeline is not None:
            await loop.run_in_executor(executor, pipeline.close)
            pipeline = None
            state.has_position = False
            eye_baseline_notified = False
        release_tab_key("tracking stopped")

    def notice(kind: str, msg: str) -> None:
        nonlocal last_notice
        if time.monotonic() - last_notice > 3.0:
            last_notice = time.monotonic()
            broadcast(clients, json.dumps({"status": kind, "message": msg}))

    try:
        while not stop.is_set():
            release_tab_key("retrying incomplete key tap")
            if state.calibrate_requested:
                state.calibrate_requested = False
                if not state.calibration_consent:
                    broadcast(clients, json.dumps({
                        "status": "needs_consent",
                        "message": "Give local calibration consent before starting.",
                    }))
                    continue
                await run_calibration(
                    pipeline, executor, state, clients, args,
                )
                await drop_pipeline()          # rebuilt below with whatever model is on disk
                continue

            wanted = state.client_count > 0 or not args.client_only
            if not wanted:
                await drop_pipeline()
                await asyncio.sleep(0.3)
                continue

            if pipeline is None:
                try:
                    bundle = gc.load_model_bundle(args.model)
                except FileNotFoundError:
                    notice("needs_calibration",
                           "Calibration is needed. Give local calibration consent to begin.")
                    await asyncio.sleep(0.5)
                    continue
                except ValueError as exc:
                    notice("needs_calibration",
                           f"{exc} Give local calibration consent to begin.")
                    await asyncio.sleep(0.5)
                    continue
                try:
                    pipeline = await loop.run_in_executor(executor, VisionPipeline, bundle, args)
                except gc.CameraError as exc:
                    log.error("Camera unavailable: %s", exc)
                    notice("camera_error", "Camera unavailable. Close other apps using it.")
                    await asyncio.sleep(3.0)
                    continue
                except ValueError as exc:
                    log.warning("%s", exc)
                    notice("needs_calibration", str(exc))
                    await asyncio.sleep(0.5)
                    continue
                state.screen_w, state.screen_h = float(bundle["screen_w"]), float(bundle["screen_h"])
                log.info("Model loaded and camera started.")
                broadcast(clients, json.dumps({
                    "status": "model_running", "message": "Gaze model running."
                }))

            try:
                result = await loop.run_in_executor(executor, pipeline.step)
            except gc.CameraError as exc:
                log.error("Camera failure: %s", exc)
                await drop_pipeline()
                await asyncio.sleep(3.0)
                continue
            if result.quit:
                log.info("Preview window closed with ESC.")
                break
            state.cursor_frozen = result.cursor_frozen
            now = time.monotonic()
            if pipeline.eye_closure.ready and not eye_baseline_notified:
                eye_baseline_notified = True
                log.info(
                    "Tab eye-closure detector ready (open EAR L/R %.3f/%.3f).",
                    *pipeline.eye_closure.baseline_ears,
                )
                broadcast(clients, json.dumps({
                    "status": "tab_gesture",
                    "phase": "ready",
                    "message": (
                        "Eye baseline ready. Close both eyes for 1 second to tap Tab; "
                        "reopen for 0.25 seconds before the next tap."
                    ),
                }))
            if now - last_eye_status_at >= 0.25:
                last_eye_status_at = now
                detector = pipeline.eye_closure
                if not result.face:
                    status_message = "No face detected. Center your face in the camera."
                    phase = "no_face"
                elif not detector.ready:
                    status_message = (
                        "Learning open-eye baseline. Face the camera with both eyes open."
                    )
                    phase = "learning"
                elif detector.awaiting_reopen:
                    status_message = (
                        f"Tab tapped. Reopen both eyes for {detector.RELEASE_S:.2f}s "
                        "to rearm. "
                        f"Eye ratios L/R {detector.last_left:.2f}/{detector.last_right:.2f}."
                    )
                    phase = "rearm"
                elif detector.hold_progress > 0.0:
                    status_message = (
                        f"Both eyes detected closed: "
                        f"{detector.hold_progress * detector.HOLD_S:.1f}/"
                        f"{detector.HOLD_S:.1f}s "
                        f"(L/R {detector.last_left:.2f}/{detector.last_right:.2f})."
                    )
                    phase = "holding"
                else:
                    status_message = (
                        "Close both eyes; each ratio must be <= "
                        f"{detector.close_ratio_l:.2f}/"
                        f"{detector.close_ratio_r:.2f} to tap Tab. Current L/R "
                        f"{detector.last_left:.2f}/{detector.last_right:.2f}."
                    )
                    phase = "tracking"
                broadcast(clients, json.dumps({
                    "status": "tab_gesture",
                    "phase": phase,
                    "message": status_message,
                    "left_ratio": detector.last_left,
                    "right_ratio": detector.last_right,
                    "hold_progress": detector.hold_progress,
                }))
            if result.face:
                state.face_seen_at = time.monotonic()
            if result.xy is not None:
                state.x, state.y = result.xy
                state.has_position = True
                if args.standalone_mouse and not state.mouse_enabled:
                    set_mouse(state, True, "standalone mode")
            if result.tab_key_tap:
                if tap_tab_key(state):
                    broadcast(clients, json.dumps({
                        "status": "tab_gesture",
                        "phase": "tapped",
                        "message": "Tab tapped; the confirmation beep should sound.",
                    }))
                else:
                    broadcast(clients, json.dumps({
                        "status": "tab_gesture",
                        "phase": "error",
                        "message": "Tab tap failed; check the EyeSync tracker log.",
                    }))
            if result.click:
                state.ws_blink_pending = True
                state.ws_click = result.click
                state.mouse_click_pending = result.click
                log.info("%s click", result.click.capitalize())
    finally:
        try:
            await drop_pipeline()
        finally:
            state.tab_key_retry_at = 0.0
            release_tab_key("tracker shutdown")
            stop.set()      # vision is the core; if it ends, shut everything down


async def _send_voice_control(process: asyncio.subprocess.Process,
                              action: str, **values) -> None:
    if process.stdin is None:
        raise RuntimeError("Voice recognizer control channel is unavailable.")
    message = json.dumps({"action": action, **values}, ensure_ascii=True)
    process.stdin.write((message + "\n").encode("utf-8"))
    await process.stdin.drain()


async def voice_command_loop(state: SharedState, stop: asyncio.Event) -> None:
    if sys.platform != "win32":
        log.error("Voice commands are supported only on Windows.")
        return
    powershell = shutil.which("powershell.exe")
    if powershell is None:
        log.error("Voice commands unavailable: powershell.exe was not found.")
        return

    try:
        process = await asyncio.create_subprocess_exec(
            powershell, "-NoLogo", "-NoProfile", "-NonInteractive",
            "-ExecutionPolicy", "Bypass", "-File",
            str(vc.speech_script_path()),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except OSError as exc:
        log.error("Could not start the local Windows speech recognizer: %s", exc)
        return

    async def drain_stderr() -> None:
        assert process.stderr is not None
        while line := await process.stderr.readline():
            message = line.decode("utf-8", errors="replace").strip()
            if message:
                log.warning("Windows speech recognizer: %s", message)

    stderr_task = asyncio.create_task(drain_stderr())
    dictation_active = False
    try:
        assert process.stdout is not None
        first_line = await asyncio.wait_for(process.stdout.readline(), timeout=15)
        if not first_line:
            raise RuntimeError("Speech recognizer exited before it became ready.")
        ready = json.loads(first_line.decode("utf-8"))
        if ready.get("kind") == "error":
            raise RuntimeError(ready.get("message", "Speech recognizer failed."))
        if ready.get("kind") != "ready":
            raise RuntimeError("Speech recognizer returned an invalid startup message.")
        log.info(
            "Offline voice recognition ready (%s, %s). Audio stays on this PC.",
            ready.get("recognizer"), ready.get("culture"),
        )

        while not stop.is_set():
            read_task = asyncio.create_task(process.stdout.readline())
            stop_task = asyncio.create_task(stop.wait())
            done, pending = await asyncio.wait(
                (read_task, stop_task), return_when=asyncio.FIRST_COMPLETED
            )
            for task in pending:
                task.cancel()
            if stop_task in done and stop_task.result():
                break
            line = read_task.result()
            if not line:
                code = await process.wait()
                raise RuntimeError(
                    f"Windows speech recognizer exited unexpectedly ({code})."
                )
            try:
                event = json.loads(line.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                log.error("Invalid message from Windows speech recognizer: %s", exc)
                continue

            if event.get("kind") == "error":
                log.error("Windows speech recognizer: %s", event.get("message"))
                continue
            if event.get("kind") == "speech_detected":
                log.info("Microphone detected speech.")
                continue
            if event.get("kind") == "speech_rejected":
                log.info(
                    "Speech was heard but did not match a command or dictation "
                    "(confidence %.2f).",
                    event.get("confidence", 0.0),
                )
                continue
            phrase = event.get("text")
            if not isinstance(phrase, str) or not phrase.strip():
                continue
            confidence = event.get("confidence", 0.0)
            if not isinstance(confidence, (int, float)) or confidence < 0.45:
                log.info(
                    "Recognized speech was below the confidence threshold "
                    "(%.2f); it was not acted on or typed.",
                    confidence if isinstance(confidence, (int, float)) else 0.0,
                )
                continue
            action = vc.command_action(phrase)
            if action is not None:
                if dictation_active and action != "start_listening":
                    dictation_active = False
                    await _send_voice_control(
                        process, "dictation", enabled=False
                    )
                if action == "start_listening":
                    dictation_active = True
                    await _send_voice_control(
                        process, "dictation", enabled=True
                    )
                    log.info("Voice dictation started.")
                elif action == "stop_listening":
                    dictation_active = False
                    state.keyboard_adjusting = False
                    await _send_voice_control(
                        process, "dictation", enabled=False
                    )
                    log.info("Voice dictation stopped; command listening remains active.")
                    await _send_voice_control(
                        process, "speak", text="Dictation stopped."
                    )
                elif action == "open_keyboard":
                    try:
                        state.keyboard_open = vc.open_onscreen_keyboard()
                        state.keyboard_opened_pending = state.keyboard_open
                        await _send_voice_control(
                            process, "speak", text="On-screen keyboard opened."
                        )
                    except OSError as exc:
                        log.error("Cannot open on-screen keyboard: %s", exc)
                        await _send_voice_control(
                            process, "speak",
                            text="I could not open the on-screen keyboard.",
                        )
                elif action == "close_keyboard":
                    state.keyboard_adjusting = False
                    try:
                        closed = vc.close_onscreen_keyboard()
                        if closed:
                            state.keyboard_open = False
                            await _send_voice_control(
                                process, "speak",
                                text="On-screen keyboard closed.",
                            )
                        else:
                            await _send_voice_control(
                                process, "speak",
                                text="The on-screen keyboard was not found.",
                            )
                    except OSError as exc:
                        log.error("Cannot close on-screen keyboard: %s", exc)
                elif action == "start_adjusting":
                    try:
                        if not state.keyboard_open:
                            await _send_voice_control(
                                process, "speak",
                                text="Open the on-screen keyboard before adjusting it.",
                            )
                            continue
                        if not vc.is_keyboard_titlebar_cursor_position():
                            await _send_voice_control(
                                process, "speak",
                                text="Move the cursor onto the keyboard title bar, then say let me adjust the on-screen keyboard.",
                            )
                        elif not state.mouse_enabled:
                            await _send_voice_control(
                                process, "speak",
                                text="Mouse control is not enabled, so I cannot move the keyboard.",
                            )
                        else:
                            state.keyboard_adjusting = True
                    except OSError as exc:
                        log.error("Cannot start keyboard repositioning: %s", exc)
                elif action == "stop_adjusting":
                    state.keyboard_adjusting = False
                    await _send_voice_control(
                        process, "speak", text="Keyboard adjustment stopped."
                    )
                elif action in {"increase_keyboard", "reduce_keyboard"}:
                    try:
                        scale = 1.15 if action == "increase_keyboard" else 1 / 1.15
                        if vc.resize_onscreen_keyboard(scale):
                            await _send_voice_control(
                                process, "speak",
                                text="On-screen keyboard size changed.",
                            )
                        else:
                            await _send_voice_control(
                                process, "speak",
                                text="Open the on-screen keyboard before changing its size.",
                            )
                    except OSError as exc:
                        log.error("Cannot resize on-screen keyboard: %s", exc)
                continue

            if event.get("kind") != "dictation" or not dictation_active:
                continue
            if vc.contains_numeric_expression(phrase):
                dictation_active = False
                await _send_voice_control(
                    process, "dictation", enabled=False
                )
                try:
                    state.keyboard_open = vc.open_onscreen_keyboard()
                    state.keyboard_opened_pending = state.keyboard_open
                except OSError as exc:
                    log.error("Cannot open on-screen keyboard for numeric input: %s", exc)
                await _send_voice_control(
                    process, "speak",
                    text="This sounds like a numeric expression. Please enter it using the on-screen keyboard.",
                )
                log.info(
                    "Numeric expression withheld from voice typing; dictation stopped."
                )
                continue
            try:
                vc.type_text(phrase)
                log.info("Voice dictation typed locally.")
            except OSError as exc:
                log.error("Could not type recognized voice text: %s", exc)
                await _send_voice_control(
                    process, "speak", text="I could not type that text."
                )
    except (OSError, RuntimeError, asyncio.TimeoutError, json.JSONDecodeError) as exc:
        log.error("Voice command service stopped: %s", exc)
    finally:
        state.keyboard_adjusting = False
        if dictation_active and process.returncode is None:
            try:
                await _send_voice_control(process, "dictation", enabled=False)
            except (BrokenPipeError, ConnectionResetError):
                pass
        if process.returncode is None:
            try:
                await _send_voice_control(process, "shutdown")
                await asyncio.wait_for(process.wait(), timeout=3)
            except (BrokenPipeError, ConnectionResetError, asyncio.TimeoutError):
                process.terminate()
                await process.wait()
        await stderr_task


FACE_LOST_PAUSE_S = 2.0        # real cursor pauses if no face is seen for this long
KILL_HOTKEY_NAME = "Ctrl+Alt+E"


class _MouseInput(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class _InputUnion(ctypes.Union):
    _fields_ = [("mi", _MouseInput)]


class _Input(ctypes.Structure):
    _anonymous_ = ("value",)
    _fields_ = [("type", wintypes.DWORD), ("value", _InputUnion)]


class LocalMouseController:
    """Inject pointer movement and button events directly into Windows."""

    INPUT_MOUSE = 0
    LEFT_DOWN, LEFT_UP = 0x0002, 0x0004
    RIGHT_DOWN, RIGHT_UP = 0x0008, 0x0010

    def __init__(self) -> None:
        if sys.platform != "win32":
            raise OSError("Direct local mouse control is currently supported on Windows.")
        self._user32 = ctypes.WinDLL("user32", use_last_error=True)
        self._user32.SetCursorPos.argtypes = (ctypes.c_int, ctypes.c_int)
        self._user32.SetCursorPos.restype = wintypes.BOOL
        self._user32.SendInput.argtypes = (
            wintypes.UINT, ctypes.POINTER(_Input), ctypes.c_int
        )
        self._user32.SendInput.restype = wintypes.UINT

    def move(self, x: int, y: int) -> None:
        if not self._user32.SetCursorPos(x, y):
            error = ctypes.get_last_error()
            raise ctypes.WinError(error) if error else OSError(
                f"Windows refused to move the cursor to ({x}, {y})."
            )

    def click(self, button: str) -> None:
        if button == "left":
            flags = (self.LEFT_DOWN, self.LEFT_UP)
        elif button == "right":
            flags = (self.RIGHT_DOWN, self.RIGHT_UP)
        else:
            raise ValueError(f"Unsupported mouse button: {button}")

        inputs = (_Input * len(flags))()
        for item, flag in zip(inputs, flags):
            item.type = self.INPUT_MOUSE
            item.mi.dwFlags = flag
        sent = self._user32.SendInput(
            len(inputs), inputs, ctypes.sizeof(_Input)
        )
        if sent != len(inputs):
            error = ctypes.get_last_error()
            raise ctypes.WinError(error) if error else OSError(
                f"Windows accepted {sent} of {len(inputs)} mouse button events."
            )

    def _button_event(self, button: str, down: bool) -> None:
        if button == "left":
            flag = self.LEFT_DOWN if down else self.LEFT_UP
        elif button == "right":
            flag = self.RIGHT_DOWN if down else self.RIGHT_UP
        else:
            raise ValueError(f"Unsupported mouse button: {button}")
        event = _Input()
        event.type = self.INPUT_MOUSE
        event.mi.dwFlags = flag
        sent = self._user32.SendInput(
            1, ctypes.byref(event), ctypes.sizeof(_Input)
        )
        if sent != 1:
            error = ctypes.get_last_error()
            action = "press" if down else "release"
            raise ctypes.WinError(error) if error else OSError(
                f"Windows did not accept the mouse button {action}."
            )

    def button_down(self, button: str) -> None:
        self._button_event(button, True)

    def button_up(self, button: str) -> None:
        self._button_event(button, False)


def make_dpi_aware() -> None:
    if sys.platform == "win32":
        ctypes.windll.user32.SetProcessDPIAware()


def hotkey_kill_pressed() -> bool:
    """Global Ctrl+Alt+E (Windows). Lets the user switch the real cursor off without
    needing to click anything, even if the pointer is misbehaving."""
    if sys.platform != "win32":
        return False
    import ctypes
    down = ctypes.windll.user32.GetAsyncKeyState
    return all(down(vk) & 0x8000 for vk in (0x11, 0x12, 0x45))   # CTRL, ALT, E


def set_mouse(state: SharedState, enabled: bool, why: str) -> None:
    if enabled:
        if not state.gaze_ready:
            log.warning(
                "Mouse control remains off until gaze calibration is valid (%s).", why
            )
            return
        if state.calibrating or not state.has_position:
            log.warning("Mouse control remains off until the live preview is ready (%s).", why)
            return
    if state.mouse_enabled != enabled:
        state.mouse_enabled = enabled
        state.mouse_notify = True
        log.info("Local mouse control %s (%s)", "ENABLED" if enabled else "disabled", why)


async def mouse_loop(args: argparse.Namespace, state: SharedState,
                     stop: asyncio.Event) -> None:
    mouse = LocalMouseController()
    ticker = Ticker(MOUSE_HZ)
    last_sent: Optional[tuple[int, int]] = None
    held_button: Optional[str] = None
    log.info("Using native Windows mouse input; no external mouse hardware is required.")
    while not stop.is_set():
        await ticker.wait()
        if hotkey_kill_pressed() and state.mouse_enabled:
            set_mouse(state, False, "kill-switch hotkey")
        face_ok = time.monotonic() - state.face_seen_at < FACE_LOST_PAUSE_S
        if (not face_ok and state.tab_key_held
                and time.monotonic() >= state.tab_key_retry_at):
            try:
                vc.set_tab_key_down(False)
            except OSError as exc:
                log.error("Could not release Tab after face loss: %s", exc)
                state.tab_key_retry_at = time.monotonic() + 1.0
            else:
                state.tab_key_held = False
                state.tab_key_retry_at = 0.0
                log.info("Tab key released after face loss.")
        if state.calibrating or not state.mouse_enabled or not face_ok:
            state.mouse_click_pending = None
            state.keyboard_adjusting = False
            if held_button is not None:
                try:
                    mouse.button_up(held_button)
                except OSError as exc:
                    log.error("Failed to release held mouse button: %s", exc)
                    set_mouse(state, False, "local mouse input failed")
                held_button = None
            last_sent = None
            continue
        try:
            if state.has_position and not state.cursor_frozen:
                pos = (int(round(state.x)), int(round(state.y)))
                moved = (last_sent is None or
                         max(abs(pos[0] - last_sent[0]),
                             abs(pos[1] - last_sent[1])) >= args.deadzone)
                if moved:
                    mouse.move(*pos)
                    last_sent = pos
            requested_button = "left" if state.keyboard_adjusting else None
            if requested_button != held_button:
                if held_button is not None:
                    mouse.button_up(held_button)
                if requested_button is not None:
                    mouse.button_down(requested_button)
                held_button = requested_button
            if state.mouse_click_pending:
                mouse.click(state.mouse_click_pending)
                state.mouse_click_pending = None
        except OSError as exc:
            log.error("Local mouse input failed; disabling control: %s", exc)
            set_mouse(state, False, "local mouse input failed")
            state.mouse_click_pending = None
            if held_button is not None:
                try:
                    mouse.button_up(held_button)
                except OSError as release_exc:
                    log.error("Failed to release held mouse button: %s", release_exc)
            held_button = None
            last_sent = None
    if held_button is not None:
        try:
            mouse.button_up(held_button)
        except OSError as exc:
            log.error("Failed to release held mouse button during shutdown: %s", exc)


# ---------------------------------- websocket ---------------------------------- #
async def ws_server(args: argparse.Namespace, clients: set,
                    stop: asyncio.Event, state: SharedState) -> None:
    def withdraw_calibration_consent() -> None:
        state.calibration_consent = False
        process = state.calibration_process
        if process is not None and process.returncode is None:
            try:
                process.terminate()
            except ProcessLookupError:
                pass

    async def handler(ws) -> None:
        clients.add(ws)
        state.client_count = len(clients)
        log.info("Local client connected (%d client(s))", state.client_count)
        state.mouse_notify = True            # tell the client the current mouse state
        try:
            await ws.send(json.dumps({
                "status": "calibration_state",
                "message": (
                    "Gaze is ready. Preview is active; mouse control can be enabled. "
                    + gesture_calibration_message()
                    if state.gaze_ready else
                    calibration_needed_message(args.model)
                ),
                "calibrations_ready": state.calibration_ready,
                "mouth_open_profile_calibrated": gc.load_mouth_open_profile() is not None,
                "right_click_fallback": (
                    args.enable_click_gestures and gc.load_mouth_open_profile() is None
                ),
                "right_click_ready": (
                    args.enable_click_gestures and state.gaze_ready
                ),
                "preview_ready": state.has_position,
            }))
            if not state.gaze_ready:
                await ws.send(json.dumps({
                    "status": "needs_calibration",
                    "message": calibration_needed_message(args.model),
                }))
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                except (TypeError, ValueError):
                    continue
                if isinstance(msg, dict) and msg.get("cmd") == "mouse":
                    enabled = bool(msg.get("enabled"))
                    if enabled and not state.gaze_ready:
                        await ws.send(json.dumps({
                            "status": "needs_calibration",
                            "message": calibration_needed_message(args.model),
                        }))
                    elif enabled and (state.calibrating or not state.has_position):
                        await ws.send(json.dumps({
                            "status": "preview_not_ready",
                            "message": "Wait for the red-dot preview, check it, then enable mouse control.",
                        }))
                    else:
                        set_mouse(state, enabled, "local client request")
                    state.mouse_notify = True
                    continue
                if isinstance(msg, dict) and msg.get("cmd") == "wispr_command":
                    phrase = msg.get("text")
                    action = (
                        vc.wispr_command_action(phrase)
                        if isinstance(phrase, str) else None
                    )
                    if action is None:
                        await ws.send(json.dumps({
                            "status": "wispr_command",
                            "ok": False,
                            "message": "No supported command matched; nothing was done.",
                        }))
                        continue
                    try:
                        if action == "open_keyboard":
                            state.keyboard_open = vc.open_onscreen_keyboard()
                            state.keyboard_opened_pending = state.keyboard_open
                            message = "On-screen keyboard opened."
                        elif action == "close_keyboard":
                            state.keyboard_adjusting = False
                            closed = vc.close_onscreen_keyboard()
                            state.keyboard_open = False
                            message = (
                                "On-screen keyboard closed." if closed else
                                "The on-screen keyboard was not open."
                            )
                        elif action in {"increase_keyboard", "reduce_keyboard"}:
                            scale = 1.15 if action == "increase_keyboard" else 1 / 1.15
                            resized = vc.resize_onscreen_keyboard(scale)
                            message = (
                                "On-screen keyboard size changed." if resized else
                                "Open the on-screen keyboard before resizing it."
                            )
                        elif action == "start_adjusting":
                            if not state.keyboard_open:
                                message = "Open the on-screen keyboard before adjusting it."
                            elif not state.mouse_enabled:
                                message = "Enable head mouse control before repositioning the keyboard."
                            elif not vc.is_keyboard_titlebar_cursor_position():
                                message = "Move the cursor onto the keyboard title bar, then repeat the command."
                            else:
                                state.keyboard_adjusting = True
                                message = "Keyboard repositioning started."
                        else:
                            state.keyboard_adjusting = False
                            message = "Keyboard repositioning stopped."
                        await ws.send(json.dumps({
                            "status": "wispr_command",
                            "ok": True,
                            "message": message,
                        }))
                    except OSError as exc:
                        log.error("Wispr command failed (%s): %s", action, exc)
                        await ws.send(json.dumps({
                            "status": "wispr_command",
                            "ok": False,
                            "message": f"Command failed: {exc}",
                        }))
                    continue
                if isinstance(msg, dict) and msg.get("cmd") == "calibration_consent":
                    if msg.get("accepted"):
                        state.calibration_consent = True
                    else:
                        withdraw_calibration_consent()
                    if state.calibration_consent and not state.gaze_ready:
                        if state.calibrating or state.calibrate_requested:
                            await ws.send(json.dumps({
                                "status": "busy",
                                "message": "Calibration is already in progress.",
                            }))
                        else:
                            state.calibrate_requested = True
                    continue
                if isinstance(msg, dict) and msg.get("cmd") == "calibrate":
                    if state.calibrating or state.calibrate_requested:
                        await ws.send(json.dumps({"status": "busy",
                                                  "message": "Calibration already in progress."}))
                    elif not state.calibration_consent:
                        await ws.send(json.dumps({
                            "status": "needs_consent",
                            "message": "Give local calibration consent before starting.",
                        }))
                    else:
                        state.calibrate_requested = True
        except ConnectionClosed:
            pass                      # abrupt disconnect (tab closed, network drop)
        finally:
            clients.discard(ws)
            state.client_count = len(clients)
            if not clients:
                withdraw_calibration_consent()
                set_mouse(state, False, "last local client disconnected")
            log.info("Local client disconnected (%d client(s))", state.client_count)

    origins = None if args.allow_any_origin else DEFAULT_ALLOWED_ORIGINS + args.allow_origin
    try:
        async with serve(handler, args.ws_host, args.ws_port, origins=origins):
            log.info("Local WebSocket client endpoint on ws://%s:%d",
                     args.ws_host, args.ws_port)
            await stop.wait()
    except OSError as exc:            # e.g. port already in use
        log.error("WebSocket server failed to start (%s). Continuing without local clients.", exc)


async def broadcast_loop(state: SharedState, clients: set, stop: asyncio.Event) -> None:
    ticker = Ticker(BROADCAST_HZ)
    while not stop.is_set():
        await ticker.wait()
        # Consume the blink flag every tick so it appears in exactly ONE message
        # (and a blink with no listeners is not replayed later).
        if state.mouse_notify:
            state.mouse_notify = False
            note = json.dumps({"status": "mouse", "enabled": state.mouse_enabled,
                               "message": "Local mouse control is " +
                               ("ON. Press " + KILL_HOTKEY_NAME + " to turn it off."
                                if state.mouse_enabled else "OFF (preview only).")})
            broadcast(clients, note)
        blink = state.ws_blink_pending
        click = state.ws_click
        keyboard_opened = state.keyboard_opened_pending
        state.ws_blink_pending = False
        state.ws_click = None
        state.keyboard_opened_pending = False
        if not clients or not state.has_position or state.calibrating:
            continue
        message = json.dumps({
            "x": round(state.x, 1), "y": round(state.y, 1),
            "blink": blink, "click": click,
            "keyboard_opened": keyboard_opened,
        })
        broadcast(clients, message)   # never raises for dead peers; they are skipped


# ------------------------------------- main ------------------------------------- #
async def main_async(args: argparse.Namespace) -> None:
    executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="vision")
    state, clients, stop = SharedState(), set(), asyncio.Event()
    state.calibration_ready = calibration_assets_ready(args.model)
    state.gaze_ready = gaze_asset_ready(args.model)
    try:
        bundle = gc.load_model_bundle(args.model)
        state.screen_w, state.screen_h = float(bundle["screen_w"]), float(bundle["screen_h"])
    except (FileNotFoundError, ValueError) as exc:
        log.warning("%s Waiting for calibration from a local client.", exc)

    if not state.gaze_ready:
        log.warning("%s", calibration_needed_message(args.model))
    else:
        log.info("%s", gesture_calibration_message())
    tasks = [
        asyncio.create_task(vision_loop(executor, state, stop, clients, args)),
        asyncio.create_task(ws_server(args, clients, stop, state)),
        asyncio.create_task(broadcast_loop(state, clients, stop)),
        asyncio.create_task(mouse_loop(args, state, stop)),
    ]
    if args.enable_voice_commands:
        tasks.append(asyncio.create_task(voice_command_loop(state, stop)))

    log.info("Running%s. Press Ctrl+C to stop.",
             " (idle until a local client connects)" if args.client_only else
             " (standalone mouse control armed)" if args.standalone_mouse else "")
    try:
        await asyncio.gather(*tasks)
    finally:
        stop.set()
        executor.shutdown(wait=False)


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Live face-gaze inference + broadcast")
    ap.add_argument("--model", default=str(gc.MODEL_PATH))
    ap.add_argument("--camera", type=int, default=gc.CAMERA_INDEX)
    ap.add_argument("--ear-threshold", type=float, default=gc.EAR_THRESHOLD)
    ap.add_argument("--alpha", type=float, default=0.35,
                    help="input feature EMA (0-1], lower = steadier")
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument("--client-only", action="store_true",
                      help="wait for a local client and keep mouse control off until it explicitly enables it")
    mode.add_argument("--standalone-mouse", action="store_true",
                      help="enable local mouse control after calibration and the first live gaze position")
    ap.add_argument("--enable-click-gestures", action="store_true",
                    help="opt in to deliberate smile left-click and one-second mouth-open right-click")
    ap.add_argument("--enable-voice-commands", action="store_true",
                    help="enable offline Windows voice commands and dictation")
    ap.add_argument("--deadzone", type=int, default=10,
                    help="min pixel change before the cursor moves (steadiness)")
    ap.add_argument("--min-cutoff", type=float, default=1.2,
                    help="One-Euro min cutoff Hz, lower = steadier at rest")
    ap.add_argument("--beta", type=float, default=0.015,
                    help="One-Euro speed coefficient, higher = less lag when moving")
    ap.add_argument("--ws-host", default=WS_HOST)
    ap.add_argument("--ws-port", type=int, default=WS_PORT)
    ap.add_argument("--allow-origin", action="append", default=[],
                    help="extra Origin allowed to connect (repeatable)")
    ap.add_argument("--allow-any-origin", action="store_true",
                    help="disable the Origin allow-list")
    ap.add_argument("--preview", action="store_true", help="show camera debug window")
    args = ap.parse_args()
    if not args.client_only:
        args.standalone_mouse = True
    return args


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    args = parse_args()
    try:
        make_dpi_aware()
        asyncio.run(main_async(args))
    except KeyboardInterrupt:
        log.info("Stopped.")
    except (FileNotFoundError, ValueError, OSError, gc.CameraError) as exc:
        log.error("%s", exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
