# Face-Controlled Operating System (EyeSync Gaze Brain)

Real-time, webcam-only face and gaze tracking for hands-free computer control. It reads head position and facial expressions, moves the Windows pointer directly with smooth stabilization, and can stream gaze data to a local client. No XIAO, ESP32, or other mouse hardware is required.

```text
Webcam -> MediaPipe FaceMesh -> face features / blendshapes -> smoothing + control logic
                                   |                                            |
                       head pose + eye cues                    cursor movement / clicks
                                   |                                            |
                    +------------------+------------------+             +-------------------+
                    |                                     |             |                   |
               facial / head gesture detection    calibration model   local Windows mouse   local client
                       (landmark logic)               (9-dot model)      input (native)    (ws://localhost:8765)
```

## Features
- **Project website:** A GitHub Pages-ready, mobile-friendly guide is in [`website/`](website/); the repository's Pages workflow deploys it from that folder.
- **Head Navigation (Primary Mode):** Cursor steering mapped to natural head movement with a 1-Euro adaptive filter for jitter-free control.
- **Normal Sensitivity (`0.75x` to `0.85x` Gain):** Balanced cursor dynamics tuned for steady, responsive desktop navigation and anti-drift stability.
- **Hands-Free Facial Gestures:**
  - **Closed-mouth smile** (hold for 1.2 seconds) ➔ **Left Click**.
  - **Open your mouth** (hold for 1 second) ➔ **Right Click**.
  - **Close both eyes** (hold for 1 second) ➔ tap Tab once; reopen your eyes for at least 0.25 seconds to rearm, then close both eyes again to tap Tab again. A confirmation beep plays as Tab is pressed.
- **Wispr Flow command panel:** Dictate an exact supported keyboard command into EyeSync's local command field; it runs after a brief pause. Ordinary dictation outside that panel remains Wispr Flow's normal behavior.
- **EyeSync app icon:** The local command panel uses a custom eye-and-iris icon matching the face-tracking project.
- **Face features:** MediaPipe FaceMesh with a compact feature set; the model uses whole-face bounding-box information and landmark-derived eye/face cues for stable tracking.
- **Clicks:** Hold a closed-mouth smile for 1.2 seconds for a left-click, or hold your mouth open for 1 second for a right-click.
- **Optional local gesture calibration:** The app's Calibrate button collects numeric smile and wink samples and can create personalized both-eyes-closed Tab thresholds in `tab_profile.json`; no webcam images or video are saved. Personalized Tab thresholds are optional and built-in thresholds remain available.
- **Gesture detection:** Left-click measures mouth-corner width from face landmarks relative to a relaxed-mouth baseline, and requires a 1.2-second hold. Mouth-open gestures are excluded; relax the mouth to rearm after a click. Right-click uses mouth-opening thresholds from `mouth_open_profile.json` when available, or built-in thresholds otherwise. Gaze calibration remains required for cursor movement.
- **Calibration:** 9-point calibration with stored model parameters only; no photos or video are saved.
- **Model:** Linear ridge regression with regularised correction for stable movement between calibration points.
- **Smoothing:** A steadier feature EMA (`0.35`), One-Euro filter (`1.2 Hz` minimum cutoff), and 10-pixel movement deadzone reduce cursor jitter while keeping head movement responsive.
- **Standalone mouse control:** Moves and clicks the local Windows mouse directly; no external controller, USB HID board, serial port, or hardware firmware is needed.
- **Local client output:** WebSocket JSON updates at roughly 30 FPS; a connected local client can show a preview and explicitly enable mouse control.
- **Local preview:** OpenCV camera preview and command-line options for tracking responsiveness.
- **Dual Tracking Modes:**
  - **Head Control Mode (Default):** Direct head-pose orientation.
  - **Iris Gaze Mode:** Sub-millimeter iris estimation with MediaPipe blendshapes.
  - Toggle modes instantly with `[M]`.
- **One-Tap Re-center (`[O]`):** Recalibrates your current head posture as the monitor midpoint instantly.

## Controls & Gestures

| Action | Facial / Head Gesture | Description |
| :--- | :--- | :--- |
| **Move Cursor** | Head movement | Natural head movement steers the mouse pointer |
| **Left Click** | **Closed-mouth smile** | Hold a smile for 1.2 seconds; relax your mouth to rearm |
| **Right Click** | **Open your mouth** | Hold your mouth open for 1 second |
| **Tab (push-to-talk)** | **Close both eyes** | Hold both eyes closed for 1 second to tap Tab; reopen your eyes for at least 0.25 seconds to rearm, then repeat |
| **Recenter** | `[O]` Key | Instantly centers cursor to current head resting position |
| **Toggle Mode** | `[M]` Key | Switches between head pose and iris gaze tracking |
| **Quit** | `[Q]` Key | Exits tracking cleanly |

## Repository layout

| Path | Purpose |
|---|---|
| `gaze_core.py` | Camera, face features, blink/wink detection, filters, and model helpers |
| `calibrate.py` | Full-screen calibration and model training |
| `calibrate_tab.py` | Calibrates personalized both-eyes-closed Tab thresholds using numeric eye measurements |
| `live.py` | Live tracking, native Windows mouse control, and the local WebSocket API |
| `setup_and_start.py` | Starts EyeSync without calibration by default; `--calibrate` opts into the calibration workflow |
| `start_eyesync.bat` | Windows launcher for `live.py` |
| `EyeSync.bat` / `eyesync_app.py` | Downloadable two-button Windows app for optional sequential calibration and starting EyeSync |
| `GETTING_STARTED.txt` | Bundled quick guide for Python 3.12.10, EyeSync setup, and Handy's Tab shortcut |
| `quick_setup.py` | Creates the app's local virtual environment and installs dependencies |
| `install_autostart.bat` / `uninstall_autostart.bat` | Register / remove silent start-at-login behavior |
| `docs/protocol.md` | Local WebSocket protocol |
| `.gitignore` | Ignored cache, logs, and model artifacts |

## Quick start

### 1. Requirements
- Windows 10 / 11
- Python 3.10–3.12 (Python 3.12.10 recommended)
- Webcam

### 2. Install dependencies

```powershell
pip install -r requirements.txt
```

### 2a. Downloaded app bundle

Extract the downloaded project ZIP and double-click `EyeSync.bat` once. Setup
installs Python 3.12.10 (64-bit) from the official Python installer when Python
3.12 is not already present, installs Handy from its official release, installs
the app dependencies, creates an EyeSync desktop shortcut, and starts EyeSync.
No separate Python or Handy installer is needed. An internet connection is
required during first-time setup. Set Handy's push-to-talk shortcut to `Tab`
once in Handy's preferences. Handy is the offline speech-to-text app at
[handy.computer](https://handy.computer/); setup downloads its Windows installer
from the official [Handy GitHub releases](https://github.com/cjpais/Handy/releases).

Windows does not allow a website to launch a downloaded application without
user action. Extract the ZIP and run `EyeSync.bat`; setup handles the remaining
installation steps and starts the app.

The app's **Calibrate** button runs `calibrate.py`, then
`calibrate_left_click.py --samples-only`,
`calibrate_right_click.py --samples-only`, and `calibrate_tab.py`. It checks
success after each step and stops immediately if one fails. The Tab step records
only numeric eye-aspect-ratio values and saves personalized thresholds in
`tab_profile.json`; it does not save webcam images or video. Calibration is
optional: **Start EyeSync** can be used without calibrating first. Cursor control
remains unavailable until the gaze model is valid, and the Tab gesture uses
built-in thresholds until its optional profile is calibrated.

The webcam is opened in a low-latency 320x240 requested mode for both
calibration and tracking (some camera drivers negotiate a different actual
size). Re-run gaze calibration after changing cameras or capture modes. Existing
gaze models without camera-mode metadata are rejected rather than used with a
potentially incorrect screen mapping.

For command-line use, start EyeSync without calibration:
```powershell
python setup_and_start.py
```
To explicitly run any missing gaze and sample-calibration steps first:
```powershell
python setup_and_start.py --calibrate
```
If the default local WebSocket port (8765) is already owned by another
application and is not a compatible EyeSync tracker, setup leaves that
application running and starts this tracker on a separate available local port.
The selected WebSocket address is printed at startup.

Gaze calibration is needed for cursor movement, but is optional before starting
the app. Without a valid gaze model, EyeSync stays running with mouse control
off. Smile and wink sample collection is optional; the live gesture detectors
do not use these archives. When collected, eye samples record open eyes and separate left- and right-wink
measurements in each head pose. Smile samples are also retained locally. These
sample archives are not used by the live click detectors. Left-click
learns a relaxed-mouth baseline at startup, while right-click can use a
personalized mouth-open profile.
Each smile or eye prompt stays in its "Get ready" phase for at least five
seconds before sample recording begins. Right-click uses the measured
inner-mouth opening, with personalized thresholds from
`mouth_open_profile.json` or built-in fallback thresholds. For left-click,
the tracker measures mouth-corner width relative to the relaxed-mouth baseline
it learns at startup. A closed-mouth smile must increase that ratio by at least
15% continuously for 1.2 seconds; opening the mouth cancels the gesture.
Relaxing the mouth rearms the next click. This uses face landmarks rather than
the webcam's mouth-image texture.

**Standalone mouse control**
```powershell
python setup_and_start.py
```

Double-click `start_eyesync.bat` or run `python setup_and_start.py` to start
without forcing calibration. Add `--calibrate` to explicitly run the missing
calibration/sample steps first. If the auto-start tracker is already running,
the opt-in calibration workflow reuses its webcam instead of opening a
competing camera session. Missing personalized mouth-open thresholds use the
built-in threshold fallback.
Local cursor movement requires valid gaze calibration and a live gaze preview.
Left-click is available without a personalized gesture profile; right-click
uses the personalized mouth-open profile when available and otherwise the
built-in thresholds.
`right_click_ready` and `right_click_fallback` indicate whether right-click is
enabled and whether built-in thresholds are in use.
Press `Ctrl+Alt+E` at any time to immediately disable mouse control; press
`Q` in the preview window or `Ctrl+C` in the terminal to stop the tracker.
Facial click gestures are disabled by default for direct `live.py` use; pass
`--enable-click-gestures` to opt in. The `setup_and_start.py` workflow opens
the local Wispr command panel. Mouse input remains blocked until gaze
calibration is valid.

To keep mouse control disabled and wait for a local client to explicitly enable
it, run `python live.py --client-only`. That client can request calibration
using the protocol in [`docs/protocol.md`](docs/protocol.md).

Use `python setup_and_start.py --calibrate` for the opt-in calibration
sequence. It skips valid profiles and runs only the missing or invalid steps.

Useful `live.py` flags:
- `--client-only` (wait for a local client; mouse control requires an explicit client action)
- `--standalone-mouse` (enable cursor control after calibration and first gaze data)
- `--enable-click-gestures` (opt in to calibrated facial click gestures)
- `--preview` (camera window with gesture scores, eye ratios, and hold progress diagnostics)
- `--allow-origin <url>`
- `--deadzone`
- `--min-cutoff`
- `--alpha`

For manual source installs, install and sign in to a speech tool such as Handy
or Wispr Flow. The downloaded app setup installs Handy automatically; Wispr
Flow must be installed separately. Set Handy's push-to-talk shortcut to `Tab`
once in its preferences. The downloadable bundle includes `GETTING_STARTED.txt`
with setup steps and the required Python version.
Run `python setup_and_start.py` to open EyeSync and its local command panel
without calibrating first.
Focus the panel's command field to dictate on-screen keyboard commands, and
configure your speech tool's push-to-talk shortcut to Tab. EyeSync learns a
personal open-eye baseline at startup; keep both eyes open and face the webcam
during this brief setup. Its eye ratios are normalized per eye to accommodate
individual eye shape and webcam distance around 60–70 cm, while requiring a
clear reduction in both ratios to avoid counting ordinary eye variation as a
closure. Close both eyes and hold for 1 second to tap Tab once. Reopen
both eyes for at least 0.25 seconds to rearm, then repeat the
gesture to send another Tab tap. Live eye ratios and hold progress appear in
the command panel and camera preview. Closing only one eye does not trigger
the gesture. Camera-frame loss cancels an in-progress hold. A confirmation
beep plays as Windows accepts the Tab press.

With Handy AI push-to-talk active (Tab), dictate one of these phrases into the command field.
An exact supported phrase runs after a 1.2-second pause; press Enter to run it
immediately instead. Unrecognized text does nothing.

| Say | Result |
|---|---|
| “Open the on-screen keyboard” / “Close the on-screen keyboard” | Open or close Windows OSK |
| “Increase the size of the on-screen keyboard” / “Decrease the size of the on-screen keyboard” | Resize the OSK window |
| “Let me adjust the position of the on-screen keyboard” | Start a left-button drag if the pointer is on the OSK title bar and mouse control is enabled |
| “Done adjusting the position of the on-screen keyboard” | Stop on-screen keyboard repositioning |

To reposition the OSK, move the cursor to its title bar, then start its
position-adjustment mode and drag it. OSK dragging requires mouse control to
be enabled. The command panel uses its normal window controls for its size and
position. The existing facial left/right click
thresholds, holds, and one-shot click behavior are unchanged.

Wispr Flow processes dictated audio to provide its service; review its privacy
settings and policy before use. EyeSync's command panel only sends allow-listed
command phrases to the local tracker; other text is not executed.

## Auto-start (no manual launch)

Run `install_autostart.bat` once. EyeSync then starts silently at every Windows
login with click gestures enabled, keeping the camera off
until a local client connects. When the last client disconnects, the camera is
released.
Re-run the installer to update an existing Startup shortcut.

Downloading the repository does not register the tracker to start with Windows.
Run `install_autostart.bat` once if automatic tracker startup is wanted. Gaze
calibration is required for cursor movement; smile/wink samples and personalized
Tab thresholds are optional. The Tab gesture uses built-in thresholds when no
`tab_profile.json` has been created.

## Privacy
Calibration data (`gaze_data.npz`, `gaze_model.joblib`, `click_profile.joblib`,
`blink_profile.json`, `mouth_open_profile.json`, `tab_profile.json`) stays on
the local PC and is git-ignored. No webcam photos or video are saved.

## Sensitivity & customization
Tracking favors a steady cursor at rest with a feature EMA of `0.35`,
One-Euro minimum cutoff of `1.2 Hz`, and 10-pixel movement deadzone. During any
detected facial gesture (smile click, mouth-open click, or Tab eye closure),
the cursor stays anchored; gaze filtering resumes from that anchor after the
gesture ends. `--alpha`, `--min-cutoff`, `--beta`, and `--deadzone`
adjust the responsiveness/steadiness tradeoff.

## Limits
A plain webcam gives roughly 4-6 degrees of gaze accuracy and can drift if you move away from your calibration posture. Recalibrate when needed.

## Summary
This project is designed to help users interact with a computer without a traditional mouse or keyboard by using head motion, eye behavior, and facial gestures. It controls the local Windows mouse directly and can optionally show gaze data in a connected local client.
